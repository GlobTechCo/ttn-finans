TTN FINANCE — THREE-ARTICLE GITHUB PUBLICATION PACKAGE
Date: November 14, 2026
Repository: GlobTechCo/ttn-finans

This archive is prepared for the existing TTN Finance GitHub publication importer.
It contains three approved editorial articles, the publication-manifest.json metadata file,
and all required WebP editorial (1672x941), responsive (960x540, 480x270), and social (1200x630)
image derivatives.

Do not modify filenames, paths, HTML metadata, or manifest entries before import.
Upload this ZIP to the repository's publish-queue/ directory for automated site publication.
