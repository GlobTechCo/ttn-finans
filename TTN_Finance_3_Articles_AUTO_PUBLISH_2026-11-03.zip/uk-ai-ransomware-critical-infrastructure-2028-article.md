# UK Cyber Agency Warns AI-Powered Ransomware Is Highly Likely to Hit Critical Infrastructure by 2028

Britain’s cyber agency says artificial intelligence will make familiar attacks faster and harder to contain, putting pressure on operators to modernize security.

Britain’s National Cyber Security Centre has delivered a warning that shifts the conversation about artificial intelligence and cybercrime from hypothetical threats to operating risk. In an assessment published on November 3, the agency said it was highly likely that AI-powered malware would be used in a ransomware attack on the UK’s critical national infrastructure by 2028. It did not say such an attack had already occurred, and its assessment should not be confused with a prediction of a specific target or date.

The important distinction is how the technology changes an attacker’s economics. AI does not have to invent an entirely new category of vulnerability to cause serious damage. By shortening the time needed to identify outdated systems, draft convincing phishing messages and automate parts of an intrusion, it can make familiar weaknesses profitable to exploit at a greater scale. For infrastructure companies, the problem is less about a novel piece of software than about a shrinking window to notice and contain an attack.

## A forecast about capability, not a confirmed breach

The NCSC is part of the UK’s GCHQ intelligence agency. Its November 3 assessment considers developments through 2028 under baseline, optimistic and pessimistic scenarios. The agency describes those scenarios as plausible futures rather than guaranteed outcomes. Its most striking judgment is that ransomware using AI-powered malware will highly likely have been used against UK critical national infrastructure within that period.

The agency also judges that states including Russia and China will routinely use AI-assisted cyber capabilities in pursuit of geopolitical objectives by 2028. That is an assessment of a future threat landscape, not proof that a particular government carried out an incident described in the report. Attribution requires evidence specific to an intrusion, and the published forecast does not replace that standard.

Critical infrastructure includes systems whose disruption can spread far beyond one organization. Energy networks, transport operators, health services and the suppliers behind them are connected to everyday economic activity. Even where an attack never reaches an industrial controller, unavailable administrative systems can slow deliveries, prevent payments or force a company to stop operations as a precaution.

## The financial exposure is larger than an IT bill

Ransomware creates several kinds of cost at once. Businesses may face interruption to revenue, emergency technology spending, legal obligations, the expense of reconstructing records and the loss of customer confidence. An operator that restores its systems quickly can still find that suppliers and customers are unable to resume normal activity immediately. Companies need to model those indirect consequences rather than treating cybersecurity as a predictable annual software subscription.

That risk matters especially for industries with older equipment. Industrial systems are often designed to operate for decades, while ordinary corporate software is replaced much more frequently. A control network may have limited maintenance windows or depend on a vendor whose product is no longer supported. The NCSC’s warning therefore lands on a difficult management question: which modernization costs should be paid now to reduce the probability of a much larger interruption later?

The same debate has been developing across the wider AI economy. Our previous reporting on <a href="openai-agent-monitoring-security-gaps-2026.html">AI monitoring and security gaps</a> examined why access controls and oversight must be built into systems rather than added only after deployment. In operational technology, that principle is particularly important because security failures can affect physical services, not just information.

## What the NCSC is asking organizations to change

Richard Horne, the NCSC’s chief executive, said the era in which organizations could accept cheap technology at the expense of security had to end. The agency wants leaders to address fundamental weaknesses: unsupported systems, unnecessary internet exposure, excessive privileges and unreliable recovery plans. It argues that proven defensive practices remain valuable even as attackers adopt more capable AI tools.

These are management decisions as much as technical ones. An inventory of critical assets is essential because an organization cannot patch or isolate systems it does not know it operates. Reliable backups need to be tested against actual restoration requirements, while network segmentation can reduce the damage if one account or device is compromised. Procurement teams should also review how vendors support security updates throughout the expected life of a product.

Investors evaluating businesses that operate essential services will increasingly need to distinguish an impressive AI strategy from a credible resilience strategy. Automation can improve productivity, but it also expands the number of systems and service providers with access to sensitive workflows. Our coverage of <a href="ai-agents-enterprise-roi-2026.html">enterprise AI returns</a> has explored the challenge of translating promised efficiency into measurable business value; security and resilience belong in the same calculation.

## A two-sided technological race

The report does not suggest that defensive organizations should avoid AI altogether. Automation can help analysts prioritize alerts, investigate abnormal behavior and identify vulnerabilities before they are exploited. But the benefits depend on the quality of data, the accountability of human teams and whether the tools work under real operating pressure. A poorly configured security agent can create another access path rather than close one.

The UK government has announced investments in cyber resilience, including an initial national Cyber Shield, a real-time vulnerability capability and an AI cyber-security center of excellence. Those initiatives may improve coordination, but no national program can replace the day-to-day decisions made by operators responsible for individual networks.

The signal for businesses is therefore precise: AI is expected to accelerate established attacks, and delaying ordinary security maintenance becomes more costly as the technology improves. The NCSC has provided a risk horizon, not a countdown to an inevitable disaster. The organizations that respond most effectively will be those that can demonstrate recovery capacity, supplier accountability and sustained investment long before a major incident tests them.

## Sources and methodology
- NCSC, November 3 statement: https://www.ncsc.gov.uk/news/cyber-chief-uk-facing-ai-powered-attacks-on-critical-infrastructure-in-two-years
- NCSC, AI and cyber intrusion assessment: https://www.ncsc.gov.uk/report/artificial-intelligence-and-cyber-intrusion