# Australia Raises Interest Rates to 4.85% as Inflation Tests the Economy

The Reserve Bank of Australia has lifted its cash rate for the fifth time in 2026, leaving households and investors to weigh the cost of persistent inflation.

Australia’s central bank raised its benchmark interest rate by a quarter percentage point on November 3, taking the cash rate target to 4.85% as policymakers tried to prevent renewed price pressures from becoming entrenched. The decision places Australia among the economies where elevated energy costs, persistent domestic inflation and strong investment demand are forcing central banks to reconsider how restrictive borrowing costs must remain.

The Reserve Bank of Australia’s Monetary Policy Board voted six to three for the increase, according to the decision and reporting on the meeting. The new rate is the highest since late 2008 and represents the bank’s fifth increase in 2026. That sequence is important: the latest move is not an isolated response to one unexpectedly expensive month but another step in a broader tightening cycle.

## Why the RBA raised rates again

The RBA’s November 3 statement identifies inflation as the central concern. Higher energy and commodity prices have raised costs across the economy, while stronger demand and capacity pressures can make it harder for companies to absorb those increases without passing them on to customers. When price increases begin influencing expectations about future wages and costs, inflation can become more persistent even if an initial supply shock fades.

Consumer-price inflation exceeded 4% in the year to September, according to reporting on the bank’s latest assessment. The bank expects inflation to remain above 3% over the coming year. The gap matters because the RBA aims to keep inflation within a 2% to 3% band over time, while supporting full employment. With inflation still above that range, holding rates steady would have carried its own risk.

The decision follows a global pattern in which policymakers are distinguishing between temporary increases in the prices of imported goods and the second-round effects on domestic services, wages and expectations. Our explainer on <a href="second-round-inflation-effects-explained.html">second-round inflation effects</a> examines why the consequences of an initial price shock may last after the shock itself eases.

## Mortgage borrowers feel the pressure first

A higher policy rate does not immediately affect every borrower in the same way. Households with variable-rate loans can see repayment costs rise relatively quickly as lenders update their products. Fixed-rate borrowers may be insulated for a period but face a different borrowing environment when their terms expire. Businesses financing inventory, property or new investment must also reassess the economics of projects that looked attractive under cheaper credit.

For Australian households, the cumulative effect of five increases is more important than the additional 25 basis points announced today. Each increase reduces disposable income for affected borrowers and can change decisions about spending, saving or moving house. Even households without debt may feel the consequences if tighter credit slows hiring, property activity or discretionary consumption.

The opposite effect applies to some savers: deposit rates can rise, though the benefit depends on the speed and extent to which banks pass the central bank’s decision to customers. Higher interest income on savings does not automatically offset the larger burden on mortgage borrowers, and the distribution of that burden matters for the overall economy.

## AI investment is becoming a monetary-policy variable

One unusual aspect of the current cycle is the interplay between infrastructure demand and technology costs. Rapid investment in AI data centers can increase demand for energy, construction capacity, equipment and financing. The result is not necessarily inflationary in every circumstance: productivity improvements could eventually reduce costs. But large capital projects can add short-term pressure in sectors where available capacity is already limited.

Our earlier article on <a href="ai-data-center-electricity-demand-2026.html">data-center electricity demand</a> explored the physical constraints behind the AI investment boom. For central bankers, those constraints mean that technological innovation does not automatically produce lower prices on the timetable that financial markets would prefer.

The bank also faces uncertainty about global energy supplies and geopolitical developments. Oil prices can move sharply when investors revise their expectations about supply disruptions, as discussed in our <a href="oil-iran-diplomacy-market-risks-november-2026.html">recent oil-market analysis</a>. Such moves feed into transport, manufacturing and consumer spending at different speeds, creating a difficult environment for setting policy based on one month of market prices.

## What happens next

Governor Michele Bullock has indicated that the bank does not expect a recession, but policymakers have not ruled out further tightening. Financial markets must therefore assess both the current rate and the possibility that borrowing costs remain elevated longer than previously anticipated. A reduction in inflation expectations would help the bank, while another sustained rise in domestic prices could raise the cost of waiting.

A split six-to-three vote highlights that the decision was not without trade-offs. The minority preferred holding at 4.60%, reflecting the risk that additional tightening could suppress demand too aggressively. The majority placed greater weight on the danger of inflation remaining above target. Neither side can know with certainty how quickly previous rate increases will work through the economy.

The November decision is a reminder that an AI-driven growth narrative and an inflation challenge can coexist. Strong investment does not eliminate pressure on household budgets, and central banks cannot assume that a future productivity dividend will arrive quickly enough to contain present-day prices. The next meaningful evidence will come from inflation, employment, wage and spending data, not from the headline rate alone.

## Sources and methodology
- RBA, November 3 monetary policy decision: https://www.rba.gov.au/news/
- RBA, 2026 decisions: https://www.rba.gov.au/monetary-policy/int-rate-decisions/
- ABC, November 3 reporting: https://www.abc.net.au/news/2026-11-03/rba-lifts-interest-rates-november-2026-highest-rate-in-18-years/107340050