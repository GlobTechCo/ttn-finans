TTN FINANCE — EDITORIAL PUBLICATION PACKAGE
Date: November 17, 2026
Time: 8:21 PM EET (ISO 8601: 2026-11-17T20:21:00+02:00, Europe/Kyiv)
Package File: ttn-finance-november-17-2026.zip
Status: Ready for manual upload / import into TTN Finance GitHub repository (not yet published)

================================================================================
1. INCLUDED ARTICLES & MATCHING COVERS (3 MATERIALS)
================================================================================

1) Jensen Huang Signals He Would Return to Nvidia as Leadership Crisis Deepens
   - Section: Tech & AI
   - Slug: jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026
   - Word Count (body): 852 words
   - Markdown: articles/jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026.md
   - HTML Fragment: pages/jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026.html
   - SEO Metadata: seo/jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026.json
   - Cover Image: covers/jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026.webp (1376x768, 16:9)

2) NSA’s Classified Communications Network Goes Down, Raising Questions About US Infrastructure Reliability
   - Section: Tech & AI
   - Slug: nsa-classified-communications-network-outage-us-infrastructure-reliability-november-17-2026
   - Word Count (body): 937 words
   - Markdown: articles/nsa-classified-communications-network-outage-us-infrastructure-reliability-november-17-2026.md
   - HTML Fragment: pages/nsa-classified-communications-network-outage-us-infrastructure-reliability-november-17-2026.html
   - SEO Metadata: seo/nsa-classified-communications-network-outage-us-infrastructure-reliability-november-17-2026.json
   - Cover Image: covers/nsa-classified-communications-network-outage-us-infrastructure-reliability-november-17-2026.webp (1376x768, 16:9)

3) Software Outage Fears Add to Wall Street Sell-Off as Technology Shares Slide
   - Section: Market Analysis
   - Slug: software-outage-fears-wall-street-sell-off-technology-shares-slide-november-17-2026
   - Word Count (body): 1026 words
   - Markdown: articles/software-outage-fears-wall-street-sell-off-technology-shares-slide-november-17-2026.md
   - HTML Fragment: pages/software-outage-fears-wall-street-sell-off-technology-shares-slide-november-17-2026.html
   - SEO Metadata: seo/software-outage-fears-wall-street-sell-off-technology-shares-slide-november-17-2026.json
   - Cover Image: covers/software-outage-fears-wall-street-sell-off-technology-shares-slide-november-17-2026.webp (1376x768, 16:9)

================================================================================
2. PACKAGE DIRECTORY STRUCTURE
================================================================================

ttn-finance-november-17-2026.zip
├── articles/                  (3 full editorial Markdown source files)
├── pages/                     (3 HTML article fragments with canonical, OG & NewsArticle JSON-LD metadata)
├── covers/                    (3 standalone 16:9 WebP editorial cover photographs)
├── seo/                       (3 validated SEO JSON files with NewsArticle schema)
├── publication-manifest.json  (Master index mapping slugs, files, dates and canonical URLs)
├── README-PUBLISH.txt         (This publication guide)
└── GEMINI_INSTRUCTIONS.txt    (Editorial integrity & importer compatibility rules)

================================================================================
3. IMPORT & PUBLISHING NOTES FOR TTN FINANCE
================================================================================

- This archive contains only new article deliverables and does NOT overwrite existing site files (index.html, article-cards.js, CSS, JS, analytics, or sitemap.xml).
- Feed ttn-finance-november-17-2026.zip into your TTN Finance ZIP importer or GitHub publishing workflow so each HTML fragment is wrapped in the active site template, each WebP cover is deployed to assets/editorial/<slug>-cover.webp, and index/sitemap entries are updated cleanly.
- All three articles are scheduled with timestamp 2026-11-17T20:21:00+02:00 (November 17, 2026 · 8:21 PM EET).
