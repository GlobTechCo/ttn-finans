# Jensen Huang Signals He Would Return to Nvidia as Leadership Crisis Deepens

**Section:** Tech & AI · **Published:** November 17, 2026 · 8:21 PM EET (`2026-11-17T20:21:00+02:00`)

> Former Nvidia chief executive Jensen Huang says he would be willing to return if the company's board concluded his reinstatement would serve shareholders, employees and the business, adding fresh uncertainty hours before quarterly earnings.

![Unoccupied executive leather chair at the head of a corporate boardroom table overlooking a glass-walled AI server room](../covers/jensen-huang-signals-return-to-nvidia-leadership-crisis-november-17-2026.webp)

Jensen Huang has said he would be willing to return as Nvidia’s chief executive if the company’s board concluded that reinstating him would serve the interests of shareholders, employees and the business. The statement, released less than a week after his departure, adds a new complication to the chipmaker’s leadership transition just hours before its quarterly earnings report.

Huang acknowledged that he had made serious mistakes in his personal life and accepted responsibility for the problems they created for Nvidia’s board. He also said he was committed to cooperating with the board’s independent investigation. His statement did not amount to a formal request for reinstatement, but it made clear that he would consider returning if directors changed their position.

The former chief executive said he had received messages from employees, investors, business partners and customers urging him to resume leadership. He described Nvidia as a company operating through a particularly complex period involving technology competition, market pressure and geopolitical tensions.

The timing matters. Nvidia is preparing to report quarterly results after the US market closes on November 17. Investors are looking not only for revenue and earnings figures but also for evidence that the company can maintain its growth trajectory under interim chief executive Colette Kress. The earnings call will be her first major public test in the role.

## The board still controls the decision

Huang’s comments do not change the formal leadership structure. Nvidia’s board appointed Kress to lead the company on an interim basis after Huang’s departure and has not announced a reversal of that decision. The Guardian’s live coverage reported that directors had indicated they were not considering reinstating him, although the former chief executive’s latest statement is likely to renew questions about succession.

The distinction between public support and board authority is important. Employees, investors and business partners may express a preference for Huang’s return, but the decision remains with the directors. They must consider the findings of the independent investigation, the company’s governance obligations and the potential consequences for Nvidia’s relationships with regulators and customers.

Huang’s influence on Nvidia is unusually significant. He led the company for more than three decades, overseeing its transformation from a graphics-chip manufacturer into a central supplier of computing infrastructure for artificial intelligence. Nvidia’s processors, networking products and software ecosystem have become important components of large-scale AI development.

That history gives the leadership question financial weight. Investors are assessing whether the company’s growth depends primarily on its technology and customer demand or whether Huang’s personal leadership has become an important part of the market’s confidence in its strategy.

## Export controls add another layer of pressure

The leadership issue is unfolding alongside increased scrutiny of Nvidia’s international business. Washington has tightened restrictions on China’s access to advanced AI chips and moved to close routes that could allow Chinese companies to obtain access to Nvidia-powered computing capacity through third countries.

US authorities have also confirmed an investigation into Singapore-based Megaspeed over suspected involvement in shipments of restricted Nvidia chips to China. The US Department of Justice and Department of Commerce said the investigation had been under way since 2024, according to the Guardian’s reporting.

Nvidia has already announced the creation of a board committee responsible for oversight of national security and export-control compliance. The move signals that regulatory exposure is now a board-level concern rather than a matter handled only through routine commercial controls.

The company faces a difficult balance. China has been an important market for the semiconductor industry, but US export restrictions limit which products and services can be supplied. Any perception that Nvidia’s controls are insufficient could increase legal and political pressure, while stricter limits may reduce the company’s addressable market.

## Earnings will test investor confidence

The immediate market question is whether Nvidia can reassure investors that demand for AI infrastructure remains strong despite the leadership disruption. The company’s latest financial performance will provide evidence about sales, margins and customer spending, but management’s guidance may matter even more.

Investors will want to understand whether major cloud providers and other large customers continue to expand their AI infrastructure budgets, whether supply constraints are easing and how export restrictions affect future revenue. They will also be listening for clarity on executive responsibilities and the board’s approach to succession.

Huang’s statement introduces an additional uncertainty before that discussion. A return could restore a familiar leadership figure, but it would also raise questions about the board’s independence and the credibility of the investigation. Keeping him out of the role may preserve the current governance process, but it would require the company to demonstrate that its strategy and execution do not depend on one individual.

For now, there has been no announcement that Huang will return. His statement establishes only that he is open to the possibility. The board’s position, the outcome of its investigation and the company’s ability to deliver strong results under Kress will determine whether the episode becomes a temporary leadership disruption or a longer-term governance challenge.

The earnings report may provide investors with a clearer picture of Nvidia’s operating strength, but it is unlikely to resolve the succession question on its own.

### Sources

- Reuters: Global markets and Nvidia earnings coverage
- The Guardian: Markets drop ahead of Nvidia’s results; Huang signals willingness to return
- Associated Press: Nvidia and AI stocks face renewed volatility ahead of earnings

**Related TTN coverage:** [Anthropic’s $895 Billion in Compute Commitments](https://globtechco.github.io/ttn-finans/anthropic-895-billion-compute-commitments-november-16-2026.html) · [China’s AI Model Distillation and Chip Restrictions](https://globtechco.github.io/ttn-finans/china-us-ai-model-distillation-domestic-rivals-chip-curbs-november-17-2026.html)
