# Aramco Reports $36.3 Billion Profit as Refining Margins Lift Cash Flow

*Saudi Aramco posted $36.25 billion in third-quarter net income and stronger free cash flow, with refining and export flexibility supporting results.*

Saudi Aramco's third-quarter earnings show how a major oil producer can strengthen cash generation even as energy markets remain vulnerable to geopolitical shocks, shifting refining margins and unpredictable export routes. The Saudi energy company reported $36.252 billion in net income for the quarter, up from $26.937 billion a year earlier, according to figures published on November 3.

That headline increase should be separated from the company's adjusted result. Adjusted net income, which excludes specified items under the company's non-IFRS definition, rose a more modest 9% to $31.198 billion from $28.581 billion. The distinction is central to understanding performance: statutory profit and adjusted profit answer different questions, and neither should be presented as though it were interchangeable with the other.

For shareholders, the more durable story may be cash flow. Operating cash flow rose to $38.7 billion, while free cash flow climbed to $28.2 billion from $23.6 billion a year earlier. That allowed Aramco to maintain a sizable dividend while continuing expenditure on major oil, gas and downstream projects.

## Refining gives Aramco a stronger second engine

Aramco attributed much of the improvement to resilience across its integrated operations. Its downstream business, which includes refining and related activities, reported a 234% year-on-year increase in adjusted earnings before interest and tax. Stronger refining margins provided support at a time when crude supply routes and international pricing were unusually volatile.

Aramco's average realized crude oil price was $95.20 a barrel in the third quarter, compared with $70.10 a year earlier and $108.10 in the second quarter. That sequence reflects the scale of oil-market volatility. A comparison with last year's quarter helps explain the year-on-year earnings improvement, while the decline from the second quarter cautions against treating the recent price environment as a straight-line recovery.

This volatility was also central to our recent <a href="oil-iran-diplomacy-market-risks-november-2026.html">analysis of oil prices and Iran-related diplomatic risk</a>. Changes in perceived conflict risk can move futures prices quickly, even before any lasting change in physical supply becomes clear.

## The dividend remains a central financial commitment

The board declared a quarterly base dividend of approximately $21.9 billion, a 3.5% rise from a year earlier, payable in the fourth quarter. Dividends are significant for all shareholders, including Saudi Arabia's government, which remains the dominant owner of the company.

The ratio of free cash flow to declared distributions is worth monitoring. Third-quarter free cash flow of $28.2 billion exceeded the quarterly base dividend, giving the company room to support investment and financial obligations. Yet coverage in a single quarter should not be mistaken for a permanent guarantee; capital spending, oil prices and changes in working capital can alter cash generation substantially.

Capital expenditure was $10.524 billion, down from $12.555 billion in the comparable period a year earlier. Aramco continues to pursue major upstream and gas developments, including the Zuluf increment, the second phase of Jafurah, the Fadhili Gas Plant expansion and the Dammam development. These projects have different operating and investment profiles and will affect future production flexibility on different timetables.

Aramco's reported gearing ratio fell to 5.5% at the end of September from 6.2% at the end of June. That suggests improvement in one measure of indebtedness, but the company still faces the broad financial demands associated with an enormous energy infrastructure portfolio.

## Supply security is becoming an investment issue

Management emphasized the value of its East-West Pipeline, which creates an additional export route and reduces exclusive reliance on shipping through the Strait of Hormuz. Aramco also said it was exploring further overseas storage and alternative export options. Such flexibility is particularly valuable during periods of geopolitical tension because it can support deliveries when particular ports or routes face disruption.

This is not merely an operational concern. Investors price energy companies partly on the reliability of their ability to deliver products, not solely on the spot price of crude. Refinery operations, storage capacity, maritime insurance, port access and pipeline infrastructure therefore have financial significance. Our report on <a href="opec-plus-december-oil-output-targets-unchanged-november-2026.html">OPEC+ production decisions</a> offers related context on the balance between stated output targets and practical supply conditions.

## What investors should watch next

The immediate assessment is that Aramco delivered stronger cash generation and maintained dividend capacity through a difficult quarter. It did so with a combination of improved refining results, substantial oil production and logistics flexibility. The company's results also show how important it is to distinguish adjusted net income from its larger statutory profit.

The next set of indicators will include realized crude prices, downstream refining margins, spending on major projects and the practical availability of alternative export routes. If geopolitical tensions ease, some of the premium embedded in crude prices may recede; if disruption persists, reliability and storage could carry greater value.

Aramco's latest quarter demonstrates the financial advantages of scale and integration, but it is not a forecast that oil prices or earnings will remain elevated. For long-term investors, the central question is whether the company can preserve disciplined capital spending and sufficient cash flow across several very different market conditions.

### Sources and verification
- [Aramco Q3 2026 results and financial tables](https://www.zawya.com/en/press-release/government-news/aramco-announces-third-quarter-2026-results-1882995)
- [Aramco investor relations](https://www.aramco.com/investors)
- [Reuters: energy markets and crude volatility](https://www.reuters.com/commentary/reuters-open-interest/global-markets-view-usa-2026-11-03/)
