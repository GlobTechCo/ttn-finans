# Palantir Revenue Nearly Doubles, but Slower Deal Growth Tests Its AI Valuation

*Palantir reported $2.31 billion in third-quarter revenue and a stronger outlook, yet softer contract momentum prompted scrutiny of its lofty AI valuation.*

Palantir has delivered the kind of quarterly growth that most established software businesses would consider extraordinary. Yet investors found an uncomfortable question inside its latest earnings report: how quickly must a company grow to justify the expectations already reflected in its share price?

The US data analytics and artificial intelligence company reported third-quarter revenue of $2.313 billion, up 96% from a year earlier and 20% from the previous quarter. Its US commercial business grew 148% year on year to $984 million, moving ahead of US government revenue of $953 million for the first time. Those numbers demonstrated that the company's AI-driven expansion is increasingly reaching businesses rather than relying solely on public-sector contracts.

The stock nevertheless faced selling pressure on November 3, after the results were released the previous evening. Investors looked beyond the headline revenue beat to the pace of newly signed business, where growth was notably less spectacular.

## Revenue is accelerating faster than new contract value

Palantir recorded $2.918 billion in total contract value closed during the quarter, a 6% year-on-year increase. Its US commercial contract value was $1.463 billion, up 11%. Those are positive figures, but they stand in sharp contrast to the near doubling of revenue and the triple-digit growth rate for US commercial sales.

The distinction matters because revenue reflects software and services delivered and recognized during the period, while contract value represents an estimate of new business commitments. Neither metric perfectly predicts the other. Contract value can fluctuate with deal timing and duration, and large awards can make any single quarter unusually volatile. Still, slower bookings raise questions about how long today's revenue acceleration can continue.

The company said it closed 212 deals worth at least $1 million, including 64 valued at $10 million or more. Its remaining deal value for the US commercial business reached $6.517 billion, up 79% from a year ago. This supports the argument that Palantir retains a substantial pipeline, even if the pace of fresh bookings softened in the latest quarter.

For investors, the debate is less about whether demand for enterprise AI exists than how that demand translates into repeatable, increasingly profitable contracts. The broader challenge of moving AI pilots into sustained deployments is one we have explored in our <a href="ai-agents-enterprise-roi-2026.html">coverage of enterprise AI returns</a>.

## Palantir raises its forecasts again

Management guided to fourth-quarter revenue between $2.649 billion and $2.653 billion, exceeding the approximately $2.46 billion analyst expectation reported by Reuters. It also raised full-year revenue guidance to $8.530 billion to $8.534 billion, implying exceptionally rapid annual growth for a software company of its size.

Profitability figures were also striking. Palantir reported $1.085 billion in generally accepted accounting principles operating income, equal to a 47% margin, and adjusted operating income of $1.427 billion, a 62% margin. Its reported net income attributable to common stockholders was $1.128 billion. These figures reflect an unusually profitable quarter, although investors should distinguish reported accounting outcomes from recurring operational trends.

Cash generation reinforced the financial picture. Cash provided by operating activities was $1.205 billion, while adjusted free cash flow reached $1.216 billion. The company reported $10.4 billion in cash, cash equivalents and US Treasury securities, giving it significant flexibility to invest in products and operations.

## Why the AI trade is facing a more demanding market

The pressure on Palantir reflects a wider change in the way investors judge artificial intelligence companies. Initial enthusiasm over the availability of powerful models is being replaced by more exacting analysis of deployment costs, contract renewal rates and customer economics.

Palantir's platform aims to connect AI systems to an organization's operational information and decisions. That is a different proposition from selling computing infrastructure, but the two parts of the industry remain connected. Large customers need hardware, networking capacity, governance and staff training before AI tools can be deployed responsibly and at scale. Our earlier report on <a href="ai-data-center-electricity-demand-2026.html">the energy requirements of AI infrastructure</a> explains one important cost pressure across the sector.

The company's earnings highlight both sides of this opportunity. Rapid growth in commercial revenue suggests that customers are committing meaningful budgets to AI-powered software. The more moderate rise in new contract value suggests investors should not assume that the recent pace of expansion will automatically persist.

## The next test is durability, not another headline record

Three measures will be particularly important in subsequent earnings reports: growth in newly closed contract value, conversion of existing commitments into recognized revenue, and the margin needed to support higher volumes of AI deployments. US commercial growth will remain a central indicator because it now exceeds the company's US government revenue.

Management expects stronger revenue in the final quarter, but that forecast is not a guarantee. Contract signing can vary from quarter to quarter, public-sector budgets remain subject to political decisions, and corporate customers can change the pace of technology rollouts.

Palantir has proved that enterprise AI can support a multibillion-dollar quarterly software business. What the November 3 stock reaction illustrates is that investors increasingly demand a second proof: that today's growth can remain commercially durable after the most dramatic acceleration has passed.

### Sources and verification
- [Palantir Q3 earnings exhibit (SEC)](https://www.sec.gov/Archives/edgar/data/1321655/000132165526000045/a2026q3ex991pressrelease.htm)
- [Palantir shareholder letter](https://www.palantir.com/q3-2026-letter/en/)
- [Reuters: Palantir results and guidance](https://www.reuters.com/technology/palantir-tops-third-quarter-revenue-estimates-strong-ai-software-demand-2026-11-02/)
- [Business Insider: market response](https://www.businessinsider.com/palantir-stock-falls-high-earnings-expectations-ai-trade-tech-pltr-2026-11)
