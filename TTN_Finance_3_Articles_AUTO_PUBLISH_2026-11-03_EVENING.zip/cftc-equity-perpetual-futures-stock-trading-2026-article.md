# US Clears Crypto-Style Perpetual Futures on Stocks as CFTC and SEC Align

*US regulators have cleared a path for perpetual futures on individual stocks, moving a crypto-market trading model toward registered domestic venues.*

A trading structure made famous by cryptocurrency exchanges has received an important regulatory opening in the United States. The Commodity Futures Trading Commission said on November 3 that perpetual futures linked to individual company shares can begin trading on appropriately registered US markets, bringing a product associated with offshore crypto platforms closer to mainstream equity trading.

The announcement is significant because perpetual futures, commonly called perps, have no fixed expiry date. Unlike a conventional futures contract, a perpetual position does not need to be rolled into a later maturity as the calendar advances. Its price is generally kept near the underlying asset through a financing or funding mechanism, although the precise arrangements depend on the contract.

The CFTC announcement creates a lawful pathway for eligible exchanges. It should not be confused with confirmation that every platform can immediately offer the product or that trading has already started across the US stock market. Registered venues must satisfy applicable conditions, including securities-market registration requirements.

## A crypto-market structure crosses into equities

Perpetual futures became a major part of digital-asset trading because they allow traders to gain exposure to Bitcoin, Ether and other assets without owning them directly. They can be used for hedging, speculation and short exposure, but the same features that make them flexible also introduce risks. Leverage can magnify gains and losses, while funding costs can change the economics of keeping a position open over time.

Now regulators are extending the structure to single-company stocks. A contract tied to an equity security occupies a complex legal position: its economic exposure resembles a stock derivative, but its design has similarities with instruments commonly supervised in commodities markets.

CFTC Chairman Michael Selig said the newly eligible products fall within a security-futures framework and can be listed on designated contract markets that are also notice-registered with the Securities and Exchange Commission for security futures. The arrangement reflects coordination between the CFTC and SEC rather than the elimination of either agency's authority.

The distinction is important for investors and market operators. A product approved under a specific legal framework may have different clearing, margin, disclosure and investor-protection requirements from a conventional stock trade. Investors should not assume a regulated perpetual contract is economically identical to owning the underlying shares.

## The decision does not remove the risks of leverage

A perpetual contract provides exposure to price changes without the same shareholder rights that generally accompany direct stock ownership. Holding the contract does not automatically confer voting rights or corporate distributions. Its return can also depend on funding payments, contract specifications and the creditworthiness of the trading and clearing arrangements.

Highly leveraged positions can be liquidated after relatively small market moves. In volatile stocks, such liquidation mechanisms can contribute to short-term price dislocations within derivatives markets, especially if liquidity is thin. The precise safeguards on US platforms will therefore matter as much as the novelty of the instrument itself.

Our earlier <a href="chip-stock-perpetuals-weekend-liquidations-2026.html">coverage of perpetuals and weekend liquidations</a> described how leveraged products can behave differently from conventional equity investments. The new regulatory opening does not make those concerns disappear. It moves a version of the market into an environment where registered venues and supervisory agencies can impose more formal controls.

## A bigger contest over market infrastructure

The decision also has strategic implications for exchanges. Companies with experience in prediction markets and digital-asset derivatives have been exploring ways to extend their trading businesses into new instruments. Conventional derivatives operators have their own infrastructure, customers and legal interests, creating the potential for competition and litigation over where stock-linked products should trade.

Reuters reported that CME Group previously challenged CFTC action concerning crypto-linked perpetual futures offered through other venues. The existence of that dispute shows that an announced regulatory pathway does not end debate over market structure or agency authority.

The latest announcement therefore does not mean every stock will become a blockchain token or that ordinary brokerage settlement is about to disappear. It gives eligible venues a route to offer a specific kind of stock derivative with regulatory oversight.

## What remains unknown

At the time of the November 3 announcement, the CFTC statement did not establish a comprehensive list of tradable stocks, name every platform that would launch immediately or set a universal first trading date. Those practical questions will determine how quickly the policy becomes a meaningful market development.

Investors should look for verified exchange launch notices, official contract specifications, financing formulas, margin limits and clearing arrangements. Those details will determine the real risk profile and cost of holding positions. For institutions, evidence of market depth and the availability of robust hedges will also be crucial.

There is a clear financial logic behind bringing more derivatives activity into supervised markets: traders may gain broader access while regulators gain visibility over behavior that could otherwise migrate to less transparent offshore venues. But this is a claim about market design, not a promise of lower risk or higher liquidity.

The broader significance of the CFTC decision is that a defining feature of crypto trading is increasingly being adapted to traditional securities. The first genuine measure of success will not be the announcement itself. It will be whether regulated contracts attract sustainable trading activity without reproducing the most destabilizing characteristics of highly leveraged offshore markets.

### Sources and verification
- [CFTC chairman statement, November 3](https://www.cftc.gov/PressRoom/SpeechesTestimony/seligstatement110326)
- [Reuters: trading in single-stock perps can begin](https://www.reuters.com/legal/government/trading-single-stock-perps-can-begin-us-regulator-says-2026-11-03/)
- [CoinDesk: CFTC equity perps](https://www.coindesk.com/policy/2026/11/03/cftc-clears-perpetual-futures-on-stocks-bringing-crypto-trading-model-to-wall-street)
- [SEC notice on single-stock perpetual futures](https://www.sec.gov/files/rules/sro/ogm/2026/34-106521.pdf)
