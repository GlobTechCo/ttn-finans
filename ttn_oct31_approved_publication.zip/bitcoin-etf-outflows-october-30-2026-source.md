# Bitcoin ETF Outflows Reported at $643 Million as Data Updates

US-listed spot bitcoin exchange-traded funds experienced a sharp reversal in flows on Friday, October 30, 2026, according to fund-tracking data reported the following morning. TokenPost, citing SoSoValue, reported net redemptions of $643.33 million across the category. However, another early report based on an incomplete fund snapshot showed only $208.59 million. The difference illustrates why ETF flow figures published shortly after the market close must be checked for late or revised fund-level entries.

## Why two reports showed different totals
The smaller $208.59 million figure included reported redemptions from ARK 21Shares' ARKB, Grayscale's GBTC and Bitwise's BITB. That report explicitly stated that it did not yet have flow entries for several other funds, including BlackRock's IBIT and Fidelity's FBTC. It was therefore an incomplete snapshot, not necessarily a final contradiction of the larger figure.

TokenPost subsequently listed IBIT outflows of $233.70 million and FBTC outflows of $201.04 million, alongside the same three smaller fund withdrawals. The five entries together total about $643.33 million. This explains the arithmetic behind the larger figure, although investors should continue to consult a live primary-data dashboard because providers may revise historical daily totals.

The difference matters because an article that quotes only the early subtotal as the full market result could understate withdrawals substantially. The reverse error is also possible if a later report has not been validated against the underlying table. TTN Finance treats the $643.33 million figure as a reported, updated total rather than an independently certified exchange statistic.

## BlackRock and Fidelity were central to the reported move
According to the updated breakdown cited by TokenPost, BlackRock's iShares Bitcoin Trust, trading as IBIT, accounted for $233.70 million in net withdrawals. Fidelity's Wise Origin Bitcoin Fund, FBTC, accounted for $201.04 million. ARKB contributed $129.55 million, GBTC $53.32 million and BITB $25.72 million. Together those figures are consistent with the reported overall outflow.

The flows are estimates of money entering or leaving the ETF structures, not a direct count of retail investors selling bitcoin. ETF shares trade continuously between market participants, while creation and redemption activity determines the net flow into or out of a fund. Daily trading volume and daily net flows measure different things. A busy trading day does not automatically mean the fund lost the same amount in assets.

Fund outflows should also be distinguished from changes in assets under management caused by the bitcoin price. A falling market value can reduce an ETF's total net assets even without net redemptions. That distinction is especially important during turbulent sessions, when asset prices and investor positioning move at the same time.

## Bitcoin and ether both faced pressure
The updated coverage also cited approximately $155.85 million of net withdrawals from US spot ether funds on October 30. That amount is a separate category and must not be accidentally included in the bitcoin-only headline. Combining the two categories yields roughly $799 million, but such a figure should always be described as a combined total rather than a bitcoin fund result.

The withdrawals occurred during a broad technology-market sell-off. Reuters reported that Intel lost 28.6% on Friday and that the Nasdaq Composite fell 2.9%, reflecting concerns about heavy AI-related investment. Cryptocurrency markets were also responding to reports of a security incident at Binance. It would nevertheless be inaccurate to attribute the entire ETF outflow to either event without fund-holder transaction evidence.

For context on institutional participation, TTN Finance has previously covered [bitcoin ETF adoption by investment institutions](bitcoin-etf-institutional-adoption.html) and [Strategy's bitcoin-related quarterly results](strategy-q3-2026-bitcoin-profit-cfo-transition.html). Neither article should be used to imply a direct causal link to October 30 withdrawals.

## What investors should watch next
The first question is whether the fund-tracking dashboards retain the revised values after subsequent data updates. The second is whether the withdrawals continue for several sessions or turn out to be a one-day reversal after preceding inflows. A single session can be notable without establishing a sustained change in demand for regulated bitcoin exposure.

The third question is whether any fund issuer publishes an amended flow report or explanation. The data identify funds and net movements, but do not establish the motives of individual investors. This distinction keeps a market report grounded in observable evidence rather than attributing investment decisions to fear or confidence without support.
