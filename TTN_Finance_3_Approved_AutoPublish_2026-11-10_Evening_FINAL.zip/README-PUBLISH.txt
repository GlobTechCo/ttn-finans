TTN Finance — Three editor-approved November 10, 2026 articles

This ZIP includes 3 HTML articles, 3 approved covers, mobile responsive assets and social cards.
Upload the ZIP unchanged to the root of main in GlobTechCo/ttn-finans.
GitHub Actions workflow "Publish approved article ZIP" imports the new slugs and rebuilds the site.
The attached images are editorial illustrations, not documentary photographs of real company premises or an actual identified consumer.

Quality checks: body word counts 700-900; 2+ inline internal links; 3 unique related articles; canonical, JSON-LD, OG, Twitter, responsive images, dated metadata.
