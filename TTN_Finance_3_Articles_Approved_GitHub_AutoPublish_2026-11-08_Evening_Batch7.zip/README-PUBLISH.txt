TTN Finance approved editorial package (November 8, 2026, evening batch)
Three article pages and three APPROVED editorial covers.
Upload the ZIP unchanged to the GitHub main branch in publish-queue/ using Add file -> Upload files -> Commit changes.
The action will import, regenerate indexes, social images and sitemap, validate the site, and commit if all checks succeed.
This package does not modify any existing published article or existing image.
