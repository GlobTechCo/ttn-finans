TTN Finance approved batch - 8 November 2026

Upload this ZIP to GlobTechCo/ttn-finans/publish-queue via GitHub > Add file > Upload files > Commit changes. Do not unpack manually. GitHub Action publishes articles, refreshes catalogs/tickers/social metadata/sitemap, and runs site audits.

This package includes the three user-approved cover images; HTML articles have linked primary/secondary sources and contextual internal TTN article links. The editorial artwork is an illustration, not evidence of events or a documentary location photograph.
