# Hong Kong Opens 24/7 Tokenized Interbank Settlement Under Project Ensemble

**Section:** Crypto  
**Deck:** The HKMA says its Ensemble pilot now supports round-the-clock interbank settlement of tokenized deposits using central bank money, with 12 banks and 20 industry participants involved.

Hong Kong has expanded a regulated experiment in digital money into an around-the-clock interbank settlement capability, marking another practical step toward tokenized financial markets. On November 2, the Hong Kong Monetary Authority announced that EnsembleTX, the pilot phase of Project Ensemble, now supports settlement of tokenized deposit transactions in tokenized central bank money on a 24-hour, seven-day basis.

The central feature is not a new cryptocurrency for retail investors. It is infrastructure intended to allow participating banks and businesses to settle certain tokenized transactions beyond conventional banking hours. The project involves 12 participating banks and 20 industry pioneers, according to the regulator. The expanded group provides a real-world setting in which financial institutions can test whether digital representations of money and assets improve operational efficiency.

The announcement also illustrates a distinction frequently obscured in discussions about digital finance: tokenization does not automatically mean replacing regulated bank money with an unbacked asset. In this project, bank deposits can be represented digitally, while final interbank settlement uses tokenized central bank money within the pilot's framework.

## What changes when bank settlement runs all day

Traditional financial markets increasingly operate across time zones, but important parts of the cash settlement process still follow business-day schedules. An institution may trade an asset outside local banking hours yet face delays before transferring the funds required to complete settlement. Those delays create liquidity needs and can leave counterparties waiting for final payment.

An always-on settlement mechanism can narrow that gap by allowing eligible institutions to transfer and settle tokenized value when conventional operating windows are closed. For corporate treasury teams, that could make it easier to manage funds across affiliated companies in different markets. For investment platforms, it could support more timely transactions involving tokenized money market funds and other digital assets.

The operational appeal is straightforward: a payment and the asset transfer it funds can potentially be coordinated more closely. The practical results, however, depend on how participating systems connect, when liquidity is available and whether legal and operational controls work across institutions. A 24/7 capability does not eliminate the need for compliance checks, risk management or contingency planning.

## How Project Ensemble reached this stage

EnsembleTX launched in November 2025 and initially used Hong Kong dollar real-time gross settlement infrastructure for interbank transactions involving tokenized deposits. The pilot allowed real-value activity in a controlled environment, including corporate treasury uses and tokenized money market fund transactions.

The November 2026 expansion builds on that earlier phase rather than announcing an entirely new payment network from scratch. The HKMA says the latest capability allows participating banks and companies to settle eligible transactions in tokenized central bank money beyond conventional operating hours. It aims to support commercialization, but the project remains a structured initiative with participating firms and defined use cases.

The regulator is coordinating with Hong Kong's Securities and Futures Commission on the broader environment for tokenized assets. This matters because settlement infrastructure cannot operate in isolation from the rules governing the securities and investment products that may be transferred through it.

The HKMA's separate FinTech Week announcement also said trials would be expanded toward regulated stablecoins. That is a future step, not proof that stablecoin settlement has already become part of every transaction on the new service.

## Standard Chartered gives the project a bank-level example

On the same day, Standard Chartered announced a tokenized deposits solution for eligible corporate clients in Hong Kong. The bank said the offering uses its proprietary blockchain infrastructure and the HKMA's EnsembleTX to support digital treasury and investment workflows. Participating clients and partners include China AMC, Finloop and PantherTrade, according to the bank's announcement.

This illustrates why the project matters commercially. A central-bank-backed settlement rail is useful only if financial institutions build services that meet actual customer needs. Treasury departments may value predictable transfers and improved visibility into liquidity. Investment platforms may want shorter delays when funds and tokenized assets change hands. Other companies may experiment with how programmable deposits fit into existing accounting and control procedures.

But bank statements about planned expansion and early adoption should not be confused with a verified market-wide transformation. The number of participants remains limited, and neither the regulator nor the bank has established that all of Hong Kong's payments or securities can now settle on the same infrastructure.

## Benefits come with new operational questions

Continuous operations can reduce delays, but they can also make liquidity management more demanding. A bank that settles transactions overnight needs controls, staffing or automation able to respond to exceptions at any hour. Institutions also require clarity about who bears a loss if instructions are disputed, systems malfunction or an authorized transaction is sent to the wrong destination.

Interoperability is another challenge. Tokenized deposits created by one bank must be usable in a framework that can coordinate transactions across participating organizations. Common technical standards matter, but so do legal finality, reconciliation processes and the treatment of assets when a participant fails. Those issues become more significant as pilots move into commercial use.

The project will be watched closely outside Hong Kong because many jurisdictions are exploring similar combinations of central bank money, bank deposits and tokenized securities. The competing approaches vary, and progress in one market does not establish that a single global model will emerge.

## What investors and companies should watch

The next meaningful evidence will come from usage rather than announcements alone: the volume and value of transactions, the number of firms conducting repeat activity, settlement reliability and the cost of operating the system. Those measures can show whether around-the-clock settlement is solving genuine problems for business clients.

Hong Kong's latest Project Ensemble milestone makes clear that tokenization is moving beyond demonstrations in at least some regulated settings. It does not establish that conventional market infrastructure is obsolete. Instead, it offers a controlled test of whether digital money can make complex financial transactions faster and more predictable while preserving the protections businesses expect from supervised institutions.

### Sources
- HKMA announcement, November 2, 2026: https://www.hkma.gov.hk/eng/news-and-media/press-releases/2026/11/20261102-5/
- HKMA FinTech Week update, November 2, 2026: https://www.hkma.gov.hk/eng/news-and-media/press-releases/2026/11/20261102-3/
- Standard Chartered release, November 2, 2026: https://www.sc.com/en/press-release/standard-chartered-launches-tokenised-deposits-in-hong-kong/
