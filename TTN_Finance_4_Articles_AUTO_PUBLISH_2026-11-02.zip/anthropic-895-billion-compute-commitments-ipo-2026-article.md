# Anthropic Discloses $895 Billion in Compute Commitments as IPO Nears

**Section:** Tech & AI  
**Deck:** The Claude developer's amended IPO filing shows soaring revenue alongside huge long-term infrastructure obligations. The commitments are not money already spent, and their timing matters as much as their scale.

Anthropic's latest filing ahead of its anticipated public-market debut has put an extraordinary number at the center of the artificial intelligence investment debate: approximately $895.4 billion in contracted spending commitments, substantially all linked to computing infrastructure. The figure appears alongside rapidly growing revenue and heavy reported losses, making the developer of Claude a revealing test case for the economics of frontier AI.

The figure is not a single purchase, a one-year capital expenditure budget or an amount the company has already paid. Its amended registration statement describes a collection of purchase agreements and leases extending across many years. Approximately $69.8 billion falls due within the 12 months following September 30, 2026, while about $447.5 billion is expected to be incurred before the end of 2030. Much of the remainder stretches from 2031 through 2045. That distinction is essential to assessing both the size of the bet and the immediate financing burden.

## Revenue growth is rapid, but the cost structure remains demanding

Anthropic reported revenue of approximately $16.96 billion for the third quarter, up from $11.56 billion in the preceding quarter, according to the amended filing and Reuters. The reported quarterly net loss narrowed to about $23.29 billion from $66.3 billion in the second quarter. The company nevertheless moved from a roughly $974 million operating profit in the previous quarter to a $567 million operating loss, underlining the expense associated with its expanding operations.

Those numbers require care. Net results include substantial non-operating accounting effects related to convertible financing instruments, so the headline loss cannot be read as an equivalent amount of cash consumed by routine services. Operating performance, cash needs and financing effects tell related but different stories. A reader using the net-loss figure alone to estimate how much Anthropic spends on servers would reach the wrong conclusion.

For the first nine months of 2026, the filing reports revenue of approximately $33.24 billion, compared with $2.55 billion during the same period of 2025. That dramatic acceleration points to robust commercial adoption. It does not resolve whether rising demand can support the infrastructure requirements embedded in long-term agreements.

## Why AI infrastructure has become a financing issue

The strongest demand for advanced AI models comes with a physical constraint: high-performance computing capacity is expensive to build, supply and operate. It requires specialized accelerators, networking, electricity, cooling and facilities with long construction and procurement lead times. Companies seeking reliable capacity may sign contracts years before the full associated revenue is visible.

Anthropic's filing describes a shift from relying solely on fixed-term cloud arrangements toward a hybrid model that includes directly leasing chips and hosting them in facilities operated on its behalf. The company calls part of that approach Anthropic Direct. In principle, separating data-center capacity from chip purchases offers flexibility: a facility can be secured ahead of the final accelerator procurement decision. In practice, the strategy increases the complexity of forecasting capacity, counterparties and financing needs.

The company warns that an infrastructure partner's inability to finance equipment purchases could undermine access to contracted computing capacity. That is a risk extending beyond Anthropic's own balance sheet. The AI supply chain now links model developers to chip designers, cloud platforms, construction projects, utility infrastructure and financing arrangements. A bottleneck in one segment can change the growth assumptions in another.

Another important qualification concerns timing. A long-dated contractual figure is not the same as a market valuation, recognized liability or forecast of annual revenue. Investors need to examine cancellation provisions, minimum purchases, lease commencements and operating cash flow, rather than comparing $895.4 billion directly with a single quarter's sales.

## Customer growth provides evidence of demand

The amended filing says more than 11,900 customers were generating at least $100,000 in annual revenue for the company, up from approximately 1,500 at the end of 2025. That expansion suggests demand is moving beyond experimentation toward sustained enterprise spending. It also raises a fundamental profitability question: how much compute must be deployed to deliver each additional dollar of revenue?

In a conventional software business, new users may add relatively little incremental delivery cost. Running and training advanced AI models can require substantial ongoing compute, particularly for complex reasoning tasks and long-running agent workflows. Pricing, model efficiency and utilization rates therefore become crucial drivers of margins. A faster model, a more efficient system or better allocation of hardware can improve the economics without an equivalent change in customer demand.

Anthropic has warned that near-term compute deployment can reduce revenue generated per dollar of compute while capacity is being brought online. That is a reminder that growth and utilization do not necessarily increase together. Spending may arrive first, with revenue dependent on later customer adoption.

## What investors will scrutinize before the IPO

An initial public offering would subject Anthropic's financial structure and forecasts to sustained public scrutiny. Potential shareholders will be able to compare growth with cash generation, assess whether infrastructure contracts align with demand and consider the effect of future financing on existing owners. The amended filing has not fixed a final offer price or the amount to be raised, so speculation about an eventual valuation should not be mistaken for transaction terms.

The broader significance reaches the entire AI sector. Long-term compute obligations can give a company capacity advantages, but they can also create fixed burdens if prices fall, customers shift to cheaper models or adoption slows. Conversely, a developer with too little committed capacity may miss orders even when demand is strong. Neither extreme guarantees a favorable outcome.

Anthropic's new disclosures make the trade-off unusually visible. The company has demonstrated exceptional revenue growth, yet the scale and duration of its infrastructure commitments mean that success will depend on far more than winning users. It will depend on converting computing capacity into durable cash flow over many years.

### Sources
- Anthropic SEC S-1/A filing, November 2, 2026: https://www.stocktitan.net/sec-filings/ANT/s-1-a-anthropic-pbc-amends-s-1-registration-statement-e8133da1f8b3.html
- Reuters, November 2, 2026: https://www.reuters.com/business/anthropics-quarterly-loss-shrinks-revenue-jumps-ahead-blockbuster-ipo-2026-11-02/
