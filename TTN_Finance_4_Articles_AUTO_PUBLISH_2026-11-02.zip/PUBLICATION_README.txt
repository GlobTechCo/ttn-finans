UPLOAD THIS ZIP UNEXTRACTED TO REPOSITORY ROOT on main. GitHub Actions workflow publish-four-nov02.yml will process it. Do not unzip manually. Four approved images and articles.
