# Bitcoin Extends Losing Streak to Seven Weeks as ETF Outflows Deepen Institutional Retreat

**Category:** Crypto

**Deck:** Bitcoin’s second-longest weekly decline has weakened sentiment, while persistent fund withdrawals raise doubts about demand.

Bitcoin has recorded seven consecutive weekly declines, extending a downturn that has erased roughly 29% of its value since early October and become the second-longest losing streak in the cryptocurrency’s trading history. The sequence highlights the pressure facing digital assets as investors reduce exposure to risk, exchange-traded funds lose capital and expectations for US interest rates become more restrictive.

Bitcoin fell from approximately $86,500 in the week beginning October 5 to around $61,100 by November 22, according to TradingView data cited by CoinDesk. The cryptocurrency briefly dropped to about $55,500 on Saturday before recovering above $61,000 by the end of Sunday. The rebound has not changed the broader weekly pattern: the latest seven-day period still ended lower.

Only one longer weekly losing streak appears in the historical data cited by CoinDesk. In 2022, Bitcoin declined for nine consecutive weeks and lost 37% as the collapse of the Terra ecosystem intensified a wider crypto-market crisis. The current sequence has not yet matched that duration, but it has renewed comparisons with previous periods of prolonged selling.

The decline is also visible in institutional investment flows. US-listed spot Bitcoin exchange-traded funds recorded approximately $1.79 billion in net outflows last week, according to CoinDesk’s report, marking the fourth consecutive week of withdrawals. The funds’ cumulative net flows for the year were negative by about $3.77 billion.

ETF flows matter because these products provide a regulated route for traditional investors to gain exposure to Bitcoin without directly holding the cryptocurrency. Persistent withdrawals suggest that some investors are reducing positions rather than using lower prices as an opportunity to increase exposure. They do not, however, reveal the motives of every investor or establish that all institutional demand has disappeared.

The difference between a price rebound and a durable recovery is therefore important. Bitcoin’s move from the weekend low toward $61,000 showed that buyers were willing to enter the market after a sharp decline. But the ETF data indicate that the broader pool of capital has not yet returned in a sustained way.

Market sentiment has deteriorated alongside prices. CoinDesk cited a reading of 6 out of 100 for the Crypto Fear and Greed Index, a level associated with extreme fear. The reading was below the level of 12 recorded after the collapse of crypto exchange FTX in 2022. Sentiment indicators are not reliable timing tools, but they help illustrate how defensive market positioning has become.

Analysts cited in the report disagree about what comes next. Michael Terpin, author of *Bitcoin Supercycle*, sees the possibility that a bottom is forming near current levels, while acknowledging that a further decline into the low-$50,000s or high-$40,000s remains possible. Bloomberg Intelligence strategist Mike McGlone has expressed a substantially more bearish view, arguing that the wider risk-asset environment could face further pressure.

Those forecasts should be treated as individual opinions, not as established price targets. Bitcoin’s historical volatility makes precise bottom predictions difficult, particularly when macroeconomic expectations and fund flows are changing at the same time.

The Federal Reserve is one of the key external factors. Traders have been pricing in further interest-rate increases, with expectations for a possible December move and additional tightening into early 2027. Higher interest rates can reduce the appeal of assets that do not generate cash flows and increase the opportunity cost of holding volatile investments. They can also tighten financial conditions, making leveraged positions more difficult to maintain.

Wednesday’s US personal consumption expenditures inflation report is therefore an important event for crypto markets as well as traditional assets. A stronger inflation reading could reinforce expectations that monetary policy will remain restrictive. A softer result could ease some of that pressure, although it would not automatically reverse ETF withdrawals or restore investor confidence.

Bitcoin’s relationship with technology shares has also become relevant. Both markets were affected by concerns about the cost and profitability of AI infrastructure investment. When investors reduce exposure to growth-oriented assets, cryptocurrencies can be sold alongside technology stocks, even though the underlying businesses and networks are fundamentally different.

The current decline does not prove that Bitcoin’s long-term investment case has changed. The network continues to operate, and the asset remains the largest cryptocurrency by market value. But market structure matters: sustained ETF outflows, weak sentiment and restrictive rate expectations can weigh on demand even without a new protocol failure or exchange crisis.

For investors, the immediate evidence to monitor is not simply whether Bitcoin can remain above $60,000. A stronger recovery would require a combination of improving fund flows, stabilising macroeconomic expectations and sustained buying after the initial rebound. Until those signals emerge, the seven-week decline remains a warning that lower prices alone have not yet restored confidence.

**TradingView tickers:** BTCUSD, IBIT, FBTC, ETHUSD, COIN

**Sources:** CoinDesk, “Bitcoin’s losing streak is second-longest ever, and some observers see more downside,” November 23, 2026; CoinDesk, “Bitcoin rebounds from 2-year low as Wall Street futures recover,” November 23, 2026.
