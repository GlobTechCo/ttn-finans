TTN FINANCE — AUTO-PUBLISH PACKAGE
Package: TTN_Finance_Three_Articles_AutoPublish_2026-11-12.zip
Prepared: 2026-11-12T20:43:00+02:00 (Europe/Kyiv)

INCLUDED FILES (14 TOTAL):
1. publication-manifest.json
2. README-PUBLISH.txt
3. ethereum-ethlabs-drops-quick-slots-quantum-security-2027.html
4. bitcoin-etfs-lose-1-44-billion-five-day-outflow-streak-november-2026.html
5. anthropic-supported-regions-policy-effective-november-12-2026.html
6. assets/editorial/ethereum-ethlabs-drops-quick-slots-quantum-security-2027-cover.jpg
7. assets/editorial/bitcoin-etfs-lose-1-44-billion-five-day-outflow-streak-november-2026-cover.jpg
8. assets/editorial/anthropic-supported-regions-policy-effective-november-12-2026-cover.jpg
9. assets/responsive/ethereum-ethlabs-drops-quick-slots-quantum-security-2027-cover-480.webp
10. assets/responsive/ethereum-ethlabs-drops-quick-slots-quantum-security-2027-cover-960.webp
11. assets/responsive/bitcoin-etfs-lose-1-44-billion-five-day-outflow-streak-november-2026-cover-480.webp
12. assets/responsive/bitcoin-etfs-lose-1-44-billion-five-day-outflow-streak-november-2026-cover-960.webp
13. assets/responsive/anthropic-supported-regions-policy-effective-november-12-2026-cover-480.webp
14. assets/responsive/anthropic-supported-regions-policy-effective-november-12-2026-cover-960.webp

NOTES:
- Original JPEG assets are preserved byte-for-byte with .jpg filenames.
- Responsive derivatives are generated at 480w and 960w in WebP format preserving 1024:572 aspect ratio.
- Upload this archive directly to the TTN Finance GitHub ZIP importer workflow.
