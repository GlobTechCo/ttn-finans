TTN Finance approved 3-article publication package.
Upload ZIP to GlobTechCo/ttn-finans repository root on main.
Do not unpack; GitHub workflow handles import, index rebuild and deployment.
Articles date 2026-11-09. Images approved by editor.
