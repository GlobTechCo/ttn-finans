# TTN Finance — GitHub Upload Package (November 18, 2026)

Package archive: `TTN_Finance_2026-11-18_GITHUB_UPLOAD.zip`  
Target repository: `https://github.com/GlobTechCo/ttn-finans`  
Publication date: `2026-11-18` (actual publication timestamp to be set by workflow at publish time)

## 1. Included Articles & Cover Mapping

1. **Isomorphic Labs Raises $5 Billion as AI Drug Discovery Moves Toward Clinical Tests**
   - **Section:** Tech & AI
   - **Slug:** `isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026`
   - **Body word count:** 831 words (within 700–900 target)
   - **Fragment:** `isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026-fragment.html`
   - **SEO JSON:** `isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026-seo.json`
   - **Markdown source:** `articles/isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026.md`
   - **Cover (16:9 WebP):** `assets/editorial/isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026-cover.webp` (1024x572)
   - **Responsive WebP:** `assets/responsive/isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026-480.webp` (480x268), `assets/responsive/isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026-960.webp` (960x536)

2. **DBS and Circle Add 24/7 USDC Access for Institutional Clients in Asia**
   - **Section:** Crypto
   - **Slug:** `dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026`
   - **Body word count:** 809 words (within 700–900 target)
   - **Fragment:** `dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026-fragment.html`
   - **SEO JSON:** `dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026-seo.json`
   - **Markdown source:** `articles/dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026.md`
   - **Cover (16:9 WebP):** `assets/editorial/dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026-cover.webp` (1024x572)
   - **Responsive WebP:** `assets/responsive/dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026-480.webp` (480x268), `assets/responsive/dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026-960.webp` (960x536)

3. **South Korea's AI Chip Boom Is Leaving Retail Investors and Consumers Behind**
   - **Section:** Market Analysis
   - **Slug:** `south-korea-chip-boom-retail-investors-consumption-november-18-2026`
   - **Body word count:** 829 words (within 700–900 target)
   - **Fragment:** `south-korea-chip-boom-retail-investors-consumption-november-18-2026-fragment.html`
   - **SEO JSON:** `south-korea-chip-boom-retail-investors-consumption-november-18-2026-seo.json`
   - **Markdown source:** `articles/south-korea-chip-boom-retail-investors-consumption-november-18-2026.md`
   - **Cover (16:9 WebP):** `assets/editorial/south-korea-chip-boom-retail-investors-consumption-november-18-2026-cover.webp` (1024x572)
   - **Responsive WebP:** `assets/responsive/south-korea-chip-boom-retail-investors-consumption-november-18-2026-480.webp` (480x268), `assets/responsive/south-korea-chip-boom-retail-investors-consumption-november-18-2026-960.webp` (960x536)

## 2. Verification Results

- **Cover-to-Article Matching:** Verified 1-to-1 unique pairing for all three articles (no duplicates, 16:9 landscape aspect ratio 1024x572, clean documentary photojournalism style without watermarks or collages).
- **Editorial Text Integrity:** Full text, headings, facts, caveats, internal links, and external source URLs preserved verbatim from the November 18, 2026 drafts.
- **Word Count Compliance:** All three articles fall within the 700–900 body word target (831, 809, and 829 words).
- **HTML & JSON Validation:** Semantic `<section class="editorial-body">` structure verified; all JSON metadata and Schema.org `NewsArticle` JSON-LD blocks validated.
- **Repository Safety:** No existing site CSS, JS, analytics, sitemap, or unrelated article files were altered or overwritten. No GitHub upload, commit, or push was executed.

## 3. Manual Upload Note

Extract `TTN_Finance_2026-11-18_GITHUB_UPLOAD.zip` into the local clone or upload the files into `GlobTechCo/ttn-finans` following your repository importer workflow.
