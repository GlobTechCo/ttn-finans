# DBS and Circle Add 24/7 USDC Access for Institutional Clients in Asia

**Section:** Crypto  
**Suggested publication date:** November 18, 2026  
**Suggested publication time:** 2:00 PM EET (scheduled slot; set the actual publication timestamp when the package is published)  
**Slug:** `dbs-circle-24-7-usdc-institutional-access-asia-november-18-2026`  
**SEO title:** DBS and Circle Expand 24/7 USDC Access in Asia | TTN Finance  
**Meta description:** DBS and Circle will let eligible institutions mint and redeem USDC around the clock, adding a bank-based route for stablecoin liquidity in Asia.

**Deck:** The Singapore bank and stablecoin issuer are connecting direct issuance and redemption with 24-hour dollar settlement. The arrangement targets institutional treasury and liquidity operations, not unrestricted retail access.

## A bank channel for round-the-clock stablecoin settlement

DBS and Circle have agreed to expand institutional access to USDC in Asia, allowing eligible clients of the Singapore bank to mint and redeem the dollar-linked stablecoin directly through DBS. The companies announced the partnership on November 18, saying the arrangement will support 24-hour, seven-day settlement between U.S. dollars and USDC.

The agreement brings together Circle's regulated stablecoin infrastructure and DBS's institutional banking and digital-asset services. For participating companies, the practical change is an additional route for moving between bank money and a blockchain-based dollar token without relying exclusively on secondary-market liquidity or conventional banking cut-off times.

The service is intended for eligible institutional clients. The announcement does not establish that every DBS customer can use it, nor does it describe a general consumer product. The companies have not published a full schedule of onboarding, fees, transaction limits or the complete list of participating jurisdictions. Those details will matter when businesses assess whether the arrangement can be incorporated into their existing treasury systems.

USDC is a stablecoin designed to maintain a value of one U.S. dollar. Circle says it is issued through regulated affiliates and supported by reserves. Stablecoins can be transferred on supported blockchain networks and are used in trading, payments and settlement. Their price stability depends on the issuer's ability to maintain confidence in the reserve, redemption process and legal structure behind the token.

## Why direct minting and redemption matter

Institutions can obtain stablecoins through exchanges, brokers and other market participants. That secondary-market route can be useful, but liquidity, spreads, operating hours and counterparty exposure may vary. Direct minting allows an eligible customer to exchange dollars for newly issued USDC through the issuer's authorised process. Redemption moves in the opposite direction, returning USDC for dollars under the applicable terms.

A bank-based channel could help corporate treasury teams manage liquidity across time zones. A business with suppliers, customers or digital-asset operations in different markets may need to move funds outside the opening hours of a local bank branch or payment system. Round-the-clock settlement could reduce timing friction, although it does not remove compliance checks, blockchain confirmation times, operational controls or the need for a receiving institution to process the funds.

DBS said the arrangement will support treasury, settlement and liquidity-management needs. These are institutional functions rather than simply a way to buy a token. Treasury departments monitor cash positions, forecast obligations and move funds between accounts or currencies. A stablecoin rail may become useful if it allows a company to manage dollar liquidity on a continuous basis while retaining access to banking services.

The distinction between token settlement and final payment is important. A blockchain transfer can occur at any hour, but the recipient may still need to convert the token, verify the transaction and meet internal accounting or regulatory requirements. A 24/7 service therefore describes the availability of the stated USD-USDC settlement arrangement, not a guarantee that every related bank transfer, supplier payment or cross-border transaction will complete instantly.

## Singapore's broader tokenized-money strategy

The partnership builds on DBS's and Circle's participation in Project BLOOM, an initiative led by the Monetary Authority of Singapore. The project explores ways to make tokenized money usable across financial networks, including interoperability between different forms of digital money and existing payment infrastructure.

DBS cited its report, *The Great Rewiring: Money in a New Order*, which found that 88% of large corporations surveyed were already deploying or piloting tokenized-money use cases, while more than three in five were adopting or planning to adopt stablecoins. Those figures describe the survey population and should not be read as proof that the same share of all companies has moved production payments onto blockchain networks.

The bank has also been developing tokenized deposit and digital-asset services. These products are not identical to USDC. A tokenized bank deposit represents a claim on a commercial bank, while a stablecoin is issued by a separate entity under its own reserve and redemption arrangements. Both may use blockchain infrastructure, but their credit, legal and operational risks differ.

## What the agreement does not resolve

The partnership does not eliminate the risks associated with stablecoins. Users remain exposed to the legal terms governing redemption, reserve management, custody, technology failures and the possibility of disruption at a bank, issuer or blockchain network. Institutions must also assess sanctions screening, anti-money-laundering controls, transaction monitoring and the treatment of digital assets under the rules in each relevant jurisdiction.

Operational resilience is another consideration. A continuous settlement service depends on technology and control systems that function across weekends and holidays. Institutions will want to understand how the bank handles outages, mistaken transfers, wallet security, reconciliation and emergency procedures. The announcement did not provide detailed service-level commitments or a complete description of those safeguards.

## A bridge, not a replacement for banking

The DBS-Circle agreement illustrates how stablecoins are increasingly being integrated through established financial institutions rather than operating only through crypto exchanges. The bank can provide institutional relationships, compliance processes and fiat liquidity, while Circle supplies the token infrastructure and issuance mechanism.

## Related TTN coverage

- [Hong Kong Passes Crypto Reporting Law With Data Collection Starting in 2027](https://globtechco.github.io/ttn-finans/hong-kong-carf-crypto-reporting-law-2027-2028.html)
- [Canton Strategic Shares Begin Tokenized Trading on a Permissioned Venue](https://globtechco.github.io/ttn-finans/canton-cntn-tokenized-stock-first-trades-tsv-2026.html)

## Sources

- [DBS: DBS and Circle expand institutional access to USDC in Asia (November 18, 2026)](https://www.dbs.com/NewsPrinter.page?locale=en&newsId=mwgm942s)
- [The Defiant: DBS, Circle Add 24/7 Institutional USDC Access in Asia](https://thedefiant.io/converge/tradfi-and-fintech/dbs-circle-add-24-7-institutional-usdc-access-in-asia)
- [Monetary Authority of Singapore: Project BLOOM](https://www.mas.gov.sg/schemes-and-initiatives/bloom)
