# Isomorphic Labs Raises $5 Billion as AI Drug Discovery Moves Toward Clinical Tests

**Section:** Tech & AI  
**Suggested publication date:** November 18, 2026  
**Suggested publication time:** 11:00 AM EET (scheduled slot; set the actual publication timestamp when the package is published)  
**Slug:** `isomorphic-labs-raises-5-billion-ai-drug-discovery-november-18-2026`  
**SEO title:** Isomorphic Labs Raises $5 Billion for AI Drug Design | TTN Finance  
**Meta description:** Isomorphic Labs raised $5 billion to scale its AI drug-design platform and advance medicine candidates toward clinical trials, a major test of the technology.

**Deck:** The Alphabet-backed company says the funding will expand its drug-design engine and move programs in oncology and immunology toward clinical development. The raise is substantial, but no drug has yet been shown to succeed in human trials.

## A record-sized bet on computational drug design

Isomorphic Labs has raised $5 billion in a Series C financing round, giving the Alphabet-backed drug-discovery company a much larger pool of capital to develop medicines using artificial intelligence. The London-based company said on November 17 that Greenoaks and Sequoia Capital co-led the round, with Andreessen Horowitz among the new investors and continued participation from Alphabet and all existing backers.

The company said the proceeds will support its proprietary drug-design engine, known as IsoDDE, expand its pipeline of internally developed and partnered medicine candidates, and build the infrastructure needed to move programs toward clinical trials. Isomorphic did not disclose a valuation in its announcement. That distinction matters because media reports about a possible valuation are not the same as a confirmed financing term.

The round follows a $2.1 billion Series B announced in May, illustrating how quickly investors have committed capital to the proposition that AI can improve the early stages of pharmaceutical research. The new financing does not, by itself, demonstrate that the platform can produce safe or effective medicines. It gives the company more resources to test that proposition in increasingly demanding stages of development.

Isomorphic was spun out of Google DeepMind in 2021 and is led by Demis Hassabis. Its research builds on advances in computational biology, including protein-structure prediction, but the commercial task is broader than predicting the shape of a protein. Drug developers must identify a biological target, design a molecule that interacts with it, establish that the molecule behaves as intended, and then test safety and efficacy through laboratory, animal and human studies.

## What the platform is designed to do

IsoDDE is described by the company as a collection of simulation models intended to work across therapeutic areas and different types of medicines. The goal is to use computational methods to predict how candidate molecules may interact with biological targets, helping researchers narrow the number of compounds that need to be synthesised and tested in laboratories.

That could make parts of discovery faster and less expensive. Pharmaceutical research often involves repeated cycles of designing a molecule, producing it, measuring its behavior and changing the design. Better predictions could reduce unproductive experiments and help scientists focus laboratory resources on more promising candidates. The potential benefit is not limited to small-molecule drugs: the company says its platform is designed to cover multiple drug modalities.

But a model prediction is not a clinical result. A molecule that appears promising in a simulation may fail when tested in cells, animals or people. Biological systems are complex, and the properties that matter in patients include absorption, distribution, metabolism, toxicity, dosing and interactions with other treatments. These questions cannot be settled by a computational score alone.

Isomorphic said its internal programs in oncology and immunology have produced positive preclinical results. Preclinical work generally takes place before human trials and can include laboratory experiments and animal studies. The company has not announced an approved medicine, and its funding announcement should not be interpreted as evidence that any candidate has demonstrated clinical benefit.

## The expensive bridge from discovery to patients

The next stage is particularly important for investors because it requires more than an advanced model. Moving a candidate into clinical development involves manufacturing suitable material, preparing regulatory submissions, designing trials, selecting sites and recruiting participants. Each step adds cost and introduces the possibility that a program will be delayed or discontinued.

Clinical trials are usually divided into phases with different objectives. Early studies focus heavily on safety, tolerability and dosage. Later studies test whether a medicine produces meaningful benefits in a larger patient population and compare those outcomes with existing care or a control group. Even a candidate that reaches human testing can fail because of side effects, weak efficacy or an inability to show an advantage over available treatments.

This is why the size of Isomorphic's financing is both an endorsement and a challenge. Investors are providing resources to move beyond demonstrations of computational capability and toward evidence that the approach can generate medicines. The company's ability to advance candidates into trials will offer a more concrete measure of progress than model benchmarks or the number of molecules generated by software.

## A test for the wider AI investment cycle

The two businesses have different economics. A software model can be deployed to many customers once built, while a drug candidate must pass a lengthy and expensive development process and may ultimately serve a narrower patient population. A successful medicine can generate substantial revenue, but the path from early research to sales is long and uncertain. That makes milestones such as validated targets, reproducible preclinical findings, trial entry and clinical outcomes more useful indicators than a large funding headline alone.

For now, the $5 billion investment gives Isomorphic the capacity to expand its research and pursue clinical milestones at a scale few young biotechnology companies can match. The decisive evidence will come from the candidates themselves: whether they progress through trials, demonstrate acceptable safety and deliver benefits that matter to patients. Until then, the financing represents a major bet on AI-enabled science, not proof that the hardest problems in drug development have been solved.

## Related TTN coverage

- [Telehealth Firm Ro Launches AI Research Lab, Seeks Drugmaker Partnerships](https://globtechco.github.io/ttn-finans/ro-ai-research-lab-patient-outcomes-2026.html)
- [Anthropic Discloses $895 Billion in Compute Commitments as IPO Nears](https://globtechco.github.io/ttn-finans/anthropic-895-billion-compute-commitments-ipo-2026.html)

## Sources

- [Isomorphic Labs: $5 billion Series C announcement (November 17, 2026)](https://storage.googleapis.com/isomorphiclabs-website-public-artifacts/ISOMORPHIC_LABS_FUNDING_17-11-26.pdf)
- [Reuters: AI drug developer Isomorphic raises $5 billion in Series C round (November 17, 2026)](https://www.reuters.com/legal/litigation/ai-drug-developer-isomorphic-raises-5-billion-series-c-round-2026-11-17/)
- [Isomorphic Labs: Company overview](https://www.isomorphiclabs.com/)
