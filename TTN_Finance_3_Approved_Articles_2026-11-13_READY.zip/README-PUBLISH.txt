TTN FINANCE — APPROVED THREE-ARTICLE PACKAGE
Date: November 13, 2026

This ZIP contains the three approved article drafts and temporary image placeholders.
Send this ZIP to Gemini with the included instruction from the accompanying chat message.
Gemini must replace ONLY the three cover images and their responsive variants, preserving
all article text, HTML structure, metadata, manifest, filenames and internal links.

Do not publish or upload this ZIP directly until Gemini has replaced all placeholder images.
After image replacement, the owner manually uploads the final ZIP to the repository's
publish-queue/ directory. The GitHub Action performs publication and site regeneration.
