# Vistra Closes Cogentrix Acquisition, Adding 5.5 GW of Gas Power Across Key U.S. Markets


**Headline:** Vistra Closes Cogentrix Acquisition, Adding 5.5 GW of Gas Power Across Key U.S. Markets

**SEO title:** Vistra Completes Cogentrix Deal, Adds 5.5 GW of Gas Capacity

**Meta description:** Vistra has closed its Cogentrix acquisition, adding 10 gas-fired plants across PJM, New England and Texas as U.S. electricity demand grows.

**Slug:** vistra-cogentrix-gas-power-acquisition-october-2026

**Deck:** The completed transaction expands Vistra’s power-generation footprint and gives investors a clearer view of the company’s exposure to regional electricity markets, fuel prices and rising power demand.

Vistra has completed its acquisition of Cogentrix Energy, bringing ten U.S. natural gas power plants with approximately 5,500 megawatts of generating capacity into its portfolio. The October 30 closing follows the receipt of regulatory approvals and turns an acquisition announced at the beginning of the year into an operating reality. For Vistra, the immediate significance is not simply the number of plants added. It is where those plants are located, how they fit with its existing generation fleet and what they could mean for cash flows in markets facing growing demand for electricity.

According to Vistra’s closing announcement, the acquired portfolio totals 5,496 megawatts and includes facilities operating in PJM, ISO New England and ERCOT. Those three regional markets have different power-demand patterns, supply constraints and pricing structures. Bringing capacity into all three gives Vistra greater geographic reach, but it also exposes the company to distinct regulatory rules and market conditions. The company says its total U.S. generation portfolio now approaches 50,000 megawatts.

The plants are a mixture of combined-cycle gas turbines, conventional combustion turbines and cogeneration. Combined-cycle systems use heat from gas turbines to produce additional electricity, generally improving fuel efficiency compared with simpler gas-fired configurations. That distinction matters because fuel cost can be a decisive factor in a power plant’s competitiveness. A plant that produces more electricity from the same amount of natural gas is typically better positioned when gas prices rise, although profitability also depends on maintenance, contracted revenues and local electricity prices.

### What Vistra actually bought

The largest individual assets include the Patriot and Hamilton-Liberty facilities in Pennsylvania, each with a reported capacity of 881 megawatts. Other sites are in New Jersey, Maryland, New Hampshire, Connecticut, Rhode Island and Maine. The portfolio also includes the Altura cogeneration facility in Texas. Cogeneration plants can supply electricity alongside useful thermal energy, creating a different operating profile from stations that sell only power into a wholesale market.

The January acquisition announcement described a transaction with approximately $2.3 billion of cash consideration, about $0.9 billion in Vistra equity and the assumption of roughly $1.5 billion in Cogentrix debt, subject to adjustments. Vistra also presented an approximately $4 billion net purchase price after accounting for the estimated value of tax benefits. Those figures should not be confused with a single cash payment at closing. The company’s prior financial filings also referred to five million shares valued at an agreed $185 per share for the seller. Final purchase accounting, debt treatment and future performance will be important to monitor in subsequent filings.

Vistra previously framed the acquisition as accretive to its ongoing operations adjusted free cash flow before growth per share, anticipating a mid-single-digit contribution in 2027 and a high-single-digit average over 2027 to 2029. Those were management forecasts published when the deal was announced, not financial results already earned by the newly acquired plants. Actual performance will depend on the assets’ availability, energy margins, fuel procurement and how efficiently they are integrated into Vistra’s commercial operations.

### Why location matters more than headline capacity

PJM covers a large multi-state electricity market in the eastern United States, while ISO New England manages the bulk power system across six northeastern states. ERCOT oversees most of Texas. Demand growth, interconnection delays and the availability of new generation have become significant questions for power markets, particularly as large industrial facilities and data centers seek reliable electricity supply. Yet it would be misleading to assume every additional megawatt from the acquisition will be sold directly to AI data centers. The announcement does not establish that kind of one-to-one commercial relationship.

The acquired plants are existing generation facilities, which means they add to Vistra’s ownership base without necessarily adding equivalent new generation capacity to the U.S. grid. This is a crucial distinction in the debate over rising national electricity demand. A change in the owner of a power station can improve the buyer’s market position and potentially its operating efficiency, but it does not by itself create a new station or resolve grid connection bottlenecks.

Ownership concentration also matters. Large power producers can optimize dispatch, hedging and customer supply across a broader portfolio. They may be able to balance periods of weak margins in one region against stronger conditions elsewhere. But bigger fleets require more capital expenditure and bring exposure to outages, unexpected fuel-price moves and changes in capacity-market rules. Regional wholesale power prices can swing sharply, and the relationship between demand growth and producer profits is neither automatic nor constant.

### The financial test comes after closing

The closing marks the beginning of the integration stage. Investors will want to see whether the acquired plants deliver the operational reliability assumed in Vistra’s forecasts, and whether maintenance spending remains within expectations. They will also examine financing costs, the trajectory of leverage and whether management maintains its stated capital-return framework while absorbing the new assets.

Natural gas generation sits at an important but contested point in the U.S. energy transition. Gas plants can supply dispatchable electricity when weather-dependent output is limited, but they also produce emissions and remain exposed to fuel-price volatility. For Vistra, the business case rests on earning adequate returns from reliable generation in regional markets, not on the assumption that demand growth guarantees higher margins. The acquisition gives the company a larger platform; the coming quarters will show how much financial value that scale produces.

**Primary sources:**
- Vistra, October 30, 2026, completion announcement: https://investor.vistracorp.com/2026-10-30-Vistra-Completes-Acquisition-of-Cogentrix-Energy%2C-Expanding-Diverse-Generation-Fleet
- Vistra, January 5, 2026, acquisition announcement: https://commercial.vistracorp.com/resources/vistra-adds-to-its-industry-leading-generation-portfolio-with-acquisition-of-cogentrix/
- Vistra SEC filing disclosure: https://investor.vistracorp.com/sec-filings?action=view&filer=Ticker%3AVST&item=1023847&pagetemplate=basic

---
