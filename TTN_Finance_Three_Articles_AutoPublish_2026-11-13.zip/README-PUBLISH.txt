TTN FINANCE — PUBLICATION PACKAGE
Batch Date: 2026-11-13T09:58:00+00:00
Repository: GlobTechCo/ttn-finans

Included Articles (3):
1. european-earnings-growth-stoxx-600-energy-2026.html (Market Analysis)
2. xfusion-1-2-billion-ai-server-ipo-2026.html (Tech & AI)
3. trm-labs-beacon-concierge-law-enforcement-crypto-freezing-2026.html (Crypto)

Structure:
- publication-manifest.json
- README-PUBLISH.txt
- <slug>.html (3 files at ZIP root)
- assets/editorial/<slug>-cover.jpg (3 original JPEG covers, 1024x572)
- assets/responsive/<slug>-cover-480.webp & -960.webp (6 genuine WebP derivatives)
