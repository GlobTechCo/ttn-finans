TTN FINANCE — THREE-ARTICLE APPROVED PACKAGE
Prepared: November 22, 2026, 5:17 AM America/New_York (EST)

This ZIP contains three complete article HTML pages, publication-manifest.json and exact Gemini cover-insertion instructions. The package intentionally contains no cover images yet.

Gemini must add exactly three WebP files at the paths listed in GEMINI_INSTRUCTIONS.txt. Do not upload this cover-free ZIP. After Gemini returns the completed ZIP, the repository importer creates the 480px and 960px responsive derivatives during normalization.
