TTN FINANCE — FINAL PUBLICATION PACKAGE
Publication date: 2026-11-17
Timezone: Europe/Kyiv
Articles: 3
Covers: 3 original 16:9 JPEG covers + 6 responsive WebP derivatives (480px & 960px)

CONTENTS:
- publication-manifest.json (root manifest with 3 article records)
- README-PUBLISH.txt (this deployment guide)
- {slug}-fragment.html (3 semantic HTML5 article fragments with responsive srcset/sizes, internal links, and source lists)
- {slug}-seo.json (3 SEO metadata & NewsArticle JSON-LD payloads)
- assets/editorial/{slug}-cover.jpg (3 approved 1024x572 16:9 editorial covers)
- assets/responsive/{slug}-cover-480.webp (3 responsive 480px WebP derivatives)
- assets/responsive/{slug}-cover-960.webp (3 responsive 960px WebP derivatives)

INCLUDED ARTICLES & WORD COUNTS (MAIN BODY):
1. new-zealand-central-bank-private-credit-global-financial-risks-november-17-2026 (832 words)
   Cover: assets/editorial/new-zealand-central-bank-private-credit-global-financial-risks-november-17-2026-cover.jpg
2. ethereum-mev-25-million-peraire-bueno-brothers-acquittal-november-17-2026 (794 words)
   Cover: assets/editorial/ethereum-mev-25-million-peraire-bueno-brothers-acquittal-november-17-2026-cover.jpg
3. china-us-ai-model-distillation-domestic-rivals-chip-curbs-november-17-2026 (813 words)
   Cover: assets/editorial/china-us-ai-model-distillation-domestic-rivals-chip-curbs-november-17-2026-cover.jpg

GITHUB UPLOAD INSTRUCTIONS:
1. Download TTN_Finance_Three_Articles_2026-11-17_FINAL.zip.
2. Upload the archive to the target publication directory in GlobTechCo/ttn-finans or extract its contents into the repository root preserving relative paths (assets/editorial/ and assets/responsive/).
3. Run or trigger the repository's GitHub Action workflow to build full pages, update sitemaps/feeds, and deploy.
4. No fabricated timestamps were added; date-only metadata (2026-11-17, Europe/Kyiv) is preserved.
