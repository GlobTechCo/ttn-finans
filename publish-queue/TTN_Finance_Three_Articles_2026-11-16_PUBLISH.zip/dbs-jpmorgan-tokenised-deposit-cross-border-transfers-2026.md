# DBS and JPMorgan Connect Tokenised Deposit Networks for 24/7 US-Singapore Transfers

DBS Group and JPMorgan Chase have launched a cross-border service that allows institutional clients to move US dollars between blockchain-based deposit accounts in Singapore and the United States around the clock. The connection links DBS Token Services with Kinexys by J.P. Morgan, turning an interoperability framework announced in 2025 into a commercially available payment route.

Ant International is the first client using the service for global treasury management. The company operates across markets and time zones, making the ability to reposition liquidity outside conventional banking hours relevant to its daily cash management. The banks said the service is designed for corporate clients that need to fund suppliers, manage subsidiaries and respond to changes in cash demand without waiting for the next banking day.

The launch is significant because it addresses one of the practical obstacles to institutional tokenisation: separate blockchain-based money systems have often operated within their own networks. A bank may be able to settle tokenised deposits quickly with customers on its own platform, but cross-bank transfers require a way to connect different systems while preserving controls over who can hold and move the money.

## A Bridge Between Two Banking Networks

The new service connects DBS Token Services with the account-based, permissioned tokenised deposit network operated through Kinexys. The banks describe the solution as an interoperability layer for transfers between their respective ecosystems. It uses Partior for settlement orchestration. DBS and JPMorgan are founding shareholders of Partior, a financial-market infrastructure company focused on clearing and settlement.

The arrangement is based on a framework the two banks announced in November 2025. That earlier initiative set out to enable tokenised value transfers between their on-chain systems. The November 16 launch moves the project from development into commercial use for eligible institutional clients.

The distinction between a tokenised deposit and a privately issued stablecoin matters. A tokenised deposit represents a deposit liability of a bank, recorded and transferred using digital-token infrastructure. It remains connected to the banking relationship and the institution that owes the deposit. A stablecoin, by contrast, is generally issued by a separate entity and depends on its own reserve, redemption and legal structure. The two instruments may both use blockchain technology, but they do not create identical claims or protections.

That difference places the DBS-JPMorgan service closer to an upgrade of wholesale banking infrastructure than to a consumer crypto payment product. The banks are not announcing an open public network or a wallet that any individual can use. Access is for institutional clients operating within the participating banks’ permissioned systems.

## Why Corporate Treasurers Want Round-the-Clock Liquidity

For multinational businesses, the timing of a payment can matter almost as much as its value. A company with suppliers in Asia and customers in North America may need to move dollars between entities while one market is closed and another is operating. Traditional cross-border payments can be constrained by banking cut-off times, local holidays, correspondent-bank processes and differences between settlement systems.

A tokenised deposit transfer can make the movement between participating accounts more continuous. That may help treasury teams reduce idle balances held in separate jurisdictions and make funds available closer to the moment they are needed. It can also support business models that operate continuously, including e-commerce and digital services.

DBS cited estimates that outbound cross-border payments in Asia could reach $24 trillion by 2033, compared with $13.5 trillion in 2025. The bank also referred to its own research indicating that 88% of surveyed corporations were deploying or piloting tokenised-money use cases. Those figures come from DBS and should be read as indicators of the bank’s market opportunity rather than independent proof that all such projects will become commercial systems.

The first client, Ant International, gives the service a practical treasury use case from launch. Its participation does not, by itself, establish how widely other corporations will adopt the network or how much payment volume will move through it. Adoption will depend on whether companies can connect their internal treasury systems, obtain the necessary banking approvals and use the service at a competitive cost.

## The 24/7 Claim Has an Important Boundary

The service is described as operating around the clock, but the banks’ own disclosure identifies a remaining limitation. Transfers within Kinexys’ Blockchain Deposit Account network are available 24 hours a day, seven days a week and are completed on a same-day basis. However, moving funds between traditional demand-deposit accounts and blockchain deposit accounts still has a three-hour downtime every Saturday, from 3 p.m. to 6 p.m. Eastern Time. DBS says an enhancement is under development.

That detail matters because a corporate treasurer needs to know whether money is available end to end, not simply whether one part of a payment network is online. A blockchain transfer may settle quickly after funds enter the tokenised environment, while the connection to conventional bank accounts can still depend on legacy operating windows.

The new link also does not remove compliance obligations. Institutional access remains permissioned, and banks must continue to manage customer due diligence, transaction monitoring, sanctions screening, operational resilience and legal obligations in each relevant jurisdiction. Interoperability makes systems more useful, but it also requires institutions to agree on how identity, instructions, settlement finality and exceptions are handled across networks.

## A Test for Tokenised Money Beyond Pilots

The launch adds to a broader shift from isolated experiments toward tokenised financial products used in live institutional workflows. Banks, market infrastructures and asset managers are testing how deposits, securities and collateral can move on shared or connected ledgers. The [Hong Kong 24/7 tokenised interbank settlement project](https://globtechco.github.io/ttn-finans/hong-kong-24-7-tokenized-interbank-settlement-2026.html) and the [DTCC’s tokenised securities service](https://globtechco.github.io/ttn-finans/dtcc-tokenization-service-live-october-2026.html) show how different parts of financial infrastructure are approaching the same challenge: making digital representations of regulated financial assets usable across institutions.

The next test for DBS and JPMorgan will be adoption beyond the first client. Relevant measures will include the number of participating institutions, transaction volumes, the range of supported use cases, transfer costs and the reliability of connections to ordinary bank accounts. Businesses will also need clarity on how errors, delayed instructions and disputes are handled.

For now, the launch demonstrates that tokenised bank deposits can be transferred between two major banking ecosystems in a live commercial setting. It does not mean that conventional cross-border payments have been replaced, or that every part of the process is available without interruption. Its importance lies in showing how banks can connect controlled digital-money systems while retaining the deposit relationship and institutional safeguards at the centre of the service.

**Sources**

- [DBS: Official announcement, November 16, 2026](https://www.dbs.com/newsroom/DBS_and_Kinexys_by_JP_Morgan_launch_industry_first_247_interoperability_solution_for_cross_border_tokenised_deposit_transfers)
- [DBS and Kinexys: Original interoperability framework, November 2025](https://www.dbs.com/newsroom/DBS_and_Kinexys_by_JP_Morgan_to_develop_framework_for_interbank_tokenised_deposit_transfers_across_multiple_blockchains)