# South Korea Bill Would Put Crypto Travel Rule Duties Directly Into Law

A South Korean lawmaker has proposed amendments that would place key cryptocurrency transfer-reporting requirements directly into the country’s financial information law, while expanding the compliance responsibilities of digital-asset exchanges. The proposal would formalise the transmission of sender and recipient information between platforms, strengthen checks on transfers involving personal wallets and make exchanges responsible for controls even when some verification work is outsourced.

The bill was introduced by Democratic Party lawmaker Kim Hyun-jung with 11 other legislators. It was submitted to the National Assembly on November 13 and reported publicly on November 16. It remains at the initial receipt stage, so the proposed changes are not current legal requirements and have not yet completed committee or plenary review.

The amendment concerns South Korea’s Act on Reporting and Use of Certain Financial Transaction Information. Its stated purpose is to clarify the information that must accompany virtual-asset transfers, tighten requirements for virtual-asset service providers and strengthen risk assessment when exchanges begin dealing with other service providers or counterparties outside the regulated exchange sector.

## From Implementing Rules to Statutory Obligations

The central provision concerns the crypto Travel Rule. Under the existing framework, virtual-asset service providers must collect and transmit information about the originator and beneficiary when qualifying transfers take place between platforms. The bill would set the core obligation more explicitly in the statute rather than leaving important details primarily to subordinate rules.

When a customer transfers digital assets from one exchange to another, the sending platform would have to provide the required sender and recipient information, while the receiving platform would have to check the information it receives. If data are missing or cannot be trusted, the receiving exchange could request additional details, hold the deposit or return the assets. Exchanges could also stop dealing with counterparties that repeatedly fail to provide the required information.

This approach is intended to reduce gaps between platforms. A transfer may be visible on a public blockchain, but a wallet address alone does not necessarily establish the identity of the person controlling it or the purpose of the transaction. Information shared between regulated service providers can help investigators connect an on-chain movement with a customer relationship, subject to applicable privacy and data-handling rules.

## Personal Wallets and New Counterparties Face Closer Checks

The proposal also addresses transfers involving self-hosted wallets. Exchanges would be required to check the wallet address and identify its owner when customers move assets to wallets they control themselves. This could increase the documentation and verification steps required for some withdrawals, particularly where a platform cannot readily establish who controls the receiving address.

The bill would also require virtual-asset service providers to conduct risk assessments before starting relationships with new exchanges or other counterparties. Checks would include whether the business genuinely exists, whether it has the required authorisation and whether it has a record of regulatory sanctions. The aim is to prevent an exchange from treating every external platform or service provider as an equally reliable destination.

These requirements could affect the way exchanges handle transfers to overseas platforms and non-custodial wallets. The practical impact would depend on the final statutory language, implementing rules and how regulators define acceptable evidence of wallet ownership and counterparty reliability.

## Outsourcing Would Not Transfer Ultimate Responsibility

Another part of the amendment concerns the allocation of compliance responsibility. Exchanges sometimes rely on external providers for customer verification or other operational checks. The proposal would make clear that outsourcing those tasks does not remove the exchange’s ultimate responsibility for performing the required customer due diligence.

The amendment would also require reporting to the Financial Intelligence Unit when important changes occur involving an exchange’s representative or major shareholder, including relevant criminal allegations. Violations of the proposed duties could attract administrative fines of up to 100 million won, according to reports on the bill.

For exchanges, the changes would likely require more formal procedures for onboarding counterparties, maintaining records of transfer data, escalating incomplete information and deciding when to pause or return an incoming transaction. Firms operating across several jurisdictions may also need to reconcile South Korean requirements with different data-protection and Travel Rule regimes abroad.

The compliance burden could fall particularly heavily on smaller platforms. Large exchanges are more likely to have dedicated legal, risk and transaction-monitoring teams, while smaller providers may need to invest in additional systems or external compliance services. The proposal does not establish the cost of implementation, but it could make the ability to demonstrate reliable controls a more important part of an exchange’s operating model.

## A Compliance Trend, Not an Enacted Rule

South Korea’s proposal comes as governments increasingly focus on how crypto platforms identify customers and share information when assets move between providers. Hong Kong, for example, has adopted a separate framework for collecting information relevant to crypto-asset transactions under its tax-reporting commitments. The [Hong Kong crypto reporting law](https://globtechco.github.io/ttn-finans/hong-kong-carf-crypto-reporting-law-2027-2028.html) is aimed at tax transparency, while the South Korean proposal is focused on anti-money-laundering controls and transfer information. They should not be treated as the same regulatory measure.

The bill also raises operational questions. Requiring more information can make illicit transfers harder, but poorly designed checks can delay legitimate withdrawals, increase customer-support costs and create inconsistent decisions between platforms. Personal-wallet ownership is particularly difficult to verify in a way that is both reliable and proportionate. Exchanges will need clear standards for acceptable evidence, secure handling of personal data and a process for resolving false positives.

The legislative status is therefore important. The bill has been submitted, but the National Assembly has not enacted it. Its language may change during committee review, and the final scope of the duties will depend on the text that lawmakers ultimately approve and any subsequent implementing rules.

For South Korea’s crypto industry, the proposal signals a possible shift from compliance obligations set mainly through subordinate regulations toward more explicit statutory duties and clearer accountability for exchanges. Whether that produces stronger enforcement without imposing unnecessary friction on ordinary transfers will depend on the final law and the standards used to apply it.

**Sources**

- [Newsis: Kim Hyun-jung proposes amendments to strengthen crypto AML controls, November 16, 2026](https://www.newsis.com/view/NISX20261116_0003869922)
- [Bill 2222764: Proposed amendment to South Korea’s financial transaction information law](https://baro.im/bill/PRC_S2T6A0B9A1F2G1E6F0D8E0C2K0K9J5/)
- [Bloomingbit: Summary of proposed exchange and personal-wallet requirements](https://en.bloomingbit.io/feed/news/124516)