# Asian Stocks Slide as US Tariff Threats Return

Category: Market Analysis

Deck: Tariff uncertainty and stubborn inflation hit Asian equities as investors await US price data and reassess technology valuations.

## Article

Asian equities fell sharply on Wednesday as renewed US tariff threats collided with a fading technology rally and fresh evidence that inflation remains difficult to contain. The selloff was broad, but its concentration in semiconductor-heavy markets showed how quickly investors can reassess the value of companies tied to global trade and artificial-intelligence spending.

MSCI’s broadest Asia-Pacific share index excluding Japan was down 3.2% during the session, Reuters reported. South Korean shares fell as much as 6.4%, Taiwan’s market dropped as much as 8.6%, and Japan’s Nikkei 225 lost as much as 3.7%. S&P 500 futures were down 0.6%. The declines followed a mixed Wall Street session on Tuesday, when the Nasdaq Composite fell 1.5%, the S&P 500 lost 0.5%, and the Dow Jones Industrial Average rose 0.9%. The split suggests investors were reducing exposure to expensive growth shares rather than liquidating every equity sector indiscriminately.

The immediate trade concern is a US investigation into alleged excess industrial capacity among 16 trading partners, including China and the European Union. The Office of the US Trade Representative is preparing findings that could provide a basis for additional tariffs, according to people familiar with the matter cited by Reuters. As of Wednesday morning, the findings had not been publicly released and no new tariff measures had been formally announced. That distinction matters: markets are pricing the risk of a policy response, not reacting to a completed tariff schedule.

For companies, the uncertainty is material even before duties are imposed. Manufacturers may delay investment, accelerate shipments, reroute supply chains or absorb higher costs while waiting for details. Exporters in Asia are particularly exposed because many depend on cross-border production networks that move components through several countries before a finished product reaches customers. A tariff aimed at one trading partner can therefore affect suppliers elsewhere, including firms that do not sell directly into the United States.

The market reaction also reflects the composition of the recent rally. Semiconductor and technology shares had benefited from optimism about AI infrastructure demand, but the same companies are sensitive to export controls, trade restrictions and changes in global capital spending. Taiwan’s and South Korea’s large technology weights amplified the regional decline. Copper’s sharp fall in Shanghai added another signal that investors were reassessing expectations for industrial demand, although one session does not establish a new trend in the global economy.

A second pressure point arrived from Australia. The Australian Bureau of Statistics reported that consumer prices rose 4.9% in the year to October, up from 4.3% in September. Trimmed-mean inflation, a measure that strips out some volatile price movements, accelerated to 3.8% from 3.6%. The monthly CPI rose 0.7% on a seasonally adjusted basis. Housing costs and transport were significant contributors, while electricity prices were affected by the expiry of government rebates.

The figures complicate the Reserve Bank of Australia’s task. The central bank has already raised rates by 125 basis points this year, according to Reuters, but underlying inflation remains above its target range. Higher borrowing costs can restrain household spending and business investment, yet persistent price pressure limits the scope for an early policy reversal. Australian shares fell 0.9% after the release, while the currency strengthened modestly as traders reassessed the interest-rate outlook.

The bond market offered a related warning. Japan’s 40-year government bond yield rose to 4.147% after weak demand at an auction, while the US 10-year Treasury yield was around 4.90%. Long-dated yields matter because they influence the discount rates used to value future corporate earnings. When yields remain elevated, high-growth companies whose valuations depend on profits expected years ahead can face additional pressure, even if their current sales are strong.

Investors were also waiting for US personal income and outlays data, including the Federal Reserve’s preferred inflation gauge, core personal consumption expenditures. The report was scheduled for Wednesday morning in Washington, making it a key test of whether price pressures are easing enough to support expectations for future rate cuts. Stronger inflation could reinforce the case for restrictive policy; a softer reading could provide relief, although it would not resolve trade uncertainty.

The immediate outlook is therefore driven by two risks that can reinforce each other. Tariffs could raise import costs and disrupt supply chains, while sticky inflation could keep financing costs high. That combination would be difficult for manufacturers, retailers and capital-intensive technology companies. It could also pressure corporate margins if businesses cannot pass higher costs to customers.

For investors, the distinction between a market correction and a lasting change in earnings expectations will depend on what happens next. The USTR findings, the detail of any policy response and the US inflation data will matter more than the headlines alone. Until those details emerge, the sharp falls in Asian technology markets are best read as a repricing of uncertainty, not proof that global growth or AI demand has already collapsed.

## Related Reading

- [Who Pays Tariffs and Who Bears Their Cost](tariffs-who-actually-pays-explained.html)
- [Why Central Banks Respond Differently to Shocks](central-bank-policy-divergence-explained.html)
- [Global Banks’ $301 Billion Trading Boom Faces a Tougher Test in 2027](global-banks-trading-revenue-record-301-billion-2026.html)

## Sources

- [Reuters – Global markets, November 25, 2026](https://www.reuters.com/world/china/global-markets-global-markets-2026-11-25/)
- [Australian Bureau of Statistics – Consumer Price Index, October 2026](https://www.abs.gov.au/statistics/economy/price-indexes-and-inflation/consumer-price-index-australia/oct-2026)
- [US Bureau of Economic Analysis – Release Schedule](https://www.bea.gov/news/schedule/full)