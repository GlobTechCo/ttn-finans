# Dell's $132.3 Billion AI Backlog Signals Infrastructure Boom

Category: Tech & AI

Deck: Dell's record AI orders lift its outlook, but backlog conversion and power constraints remain key tests.

## Article

Dell Technologies’ latest results provide one of the clearest financial measures yet of how artificial-intelligence infrastructure is reshaping the hardware industry. The company reported record quarterly revenue, a sharp increase in AI server sales and a record order backlog, then raised its full-year outlook for the third time this year. The figures show strong demand, but they also expose how much Dell’s growth now depends on customers continuing to finance large data-center projects.

For the fiscal third quarter ended October 30, Dell reported revenue of $54.94 billion, up 103% from a year earlier. GAAP diluted earnings per share were $8.82, while non-GAAP diluted EPS reached $9.45. Operating cash flow was $4.46 billion. The results were released on November 24 and exceeded the company’s previous guidance, according to its filing and earnings announcement.

The strongest performance came from the Infrastructure Solutions Group, which includes servers, networking and storage. Revenue in the segment rose 198% to $41.97 billion. AI-optimized server revenue increased 291% to $22.03 billion, while traditional servers and networking grew 235% to $15.01 billion. Storage revenue rose 24% to $4.93 billion. Segment operating income climbed 308% to $7.12 billion, lifting its operating margin to 17% from 12.4% a year earlier.

The order figures are even more striking. Dell booked $60.2 billion in AI-related orders during the quarter and ended it with a record $132.3 billion AI backlog. Management said more than 7,500 customers were deploying its AI Factory offerings, which combine computing, storage, networking and software for enterprise AI workloads. Chief Operating Officer Jeff Clarke said the company screens orders for customer quality and access to capital, land and power.

That qualification is important. A backlog is not revenue already earned, nor is it a guarantee that every order will convert on the expected schedule. Customers still need financing, electricity, data-center capacity and access to advanced processors. Projects can be delayed or resized if those constraints change. Dell’s decision to emphasize customer credit quality and access to power suggests that the company is trying to distinguish funded demand from speculative orders.

The company raised its fiscal 2027 revenue forecast to $202 billion from $192 billion, implying 78% annual growth. It lifted its AI-optimized server revenue outlook to $78 billion from $74 billion and increased its non-GAAP EPS forecast to $29.68 from $25.50. The updated revenue outlook was above the analyst consensus cited by Reuters. Dell also forecast fourth-quarter revenue of $56.3 billion and non-GAAP EPS of $8.40.

Profitability is a central part of the story. Dell’s Infrastructure Solutions Group generated $7.12 billion in operating income on $41.97 billion of revenue. The company said operating expenses, measured on a non-GAAP basis, had fallen to 7% of revenue. It also reported $4.29 billion in adjusted free cash flow for the quarter. Those figures indicate that the AI server expansion is not simply adding sales volume; it is currently contributing a larger share of operating profit.

The contrast with Dell’s PC business is substantial. Client Solutions Group revenue rose only 3% to $12.89 billion, while segment operating income fell 6% to $704 million. Consumer revenue declined 15%. The figures underline the company’s changing profile: enterprise infrastructure is driving growth while the traditional personal-computer business is expanding more slowly and facing different demand conditions.

Dell’s board also authorized an additional $25 billion in share repurchases. The company returned $4.9 billion to shareholders during the quarter through dividends and buybacks. The expanded authorization signals confidence in cash generation, but it does not remove the need to fund working capital, inventory and supply-chain commitments as server shipments rise.

The wider market remains less certain about the durability of AI spending. Investors have questioned whether cloud providers and large enterprises can sustain the current pace of capital expenditure, and recent volatility in semiconductor shares shows that strong results do not automatically translate into stable valuations. Dell shares had fallen sharply during the regular session before its earnings release, then rose in after-hours trading as investors assessed the new forecast, Reuters reported.

For suppliers, Dell’s results are evidence that AI infrastructure demand is translating into substantial orders and recognized revenue. For customers, the company’s backlog illustrates the scale of investment required to build and operate AI systems. For investors, the key questions are conversion, margins and cash collection: how quickly orders become shipped systems, whether component and power constraints raise costs, and whether customers generate enough value from AI workloads to justify continued spending.

Dell’s quarter strengthens the case that AI infrastructure is a major growth market. It does not settle the question of how profitable or durable that market will be. The next test is whether the record backlog converts into revenue and cash without eroding margins as the company scales.

## Related Reading

- [The AI Boom Faces a Balance-Sheet Test](ai-boom-capital-financing-2026.html)
- [Why Data Centers Face Electricity Constraints](ai-data-center-electricity-demand-2026.html)
- [AI Capacity Depends on More Than Chips](ai-chips-bottlenecks-2026.html)

## Sources

- [Dell Technologies – Third Quarter Fiscal 2027 Results](https://investors.delltechnologies.com/sec-filings/all-sec-filings/content/0001571996-26-000050/exhibit991earnings8kq3fy27.htm)
- [Reuters – Dell Raises Annual Forecasts After Record Quarter, November 24, 2026](https://www.reuters.com/business/dell-lifts-annual-forecasts-after-record-quarter-surging-ai-server-demand-2026-11-24/)