# Bitcoin ETF Outflows Reach $4.94 Billion as November Selling Deepens

Category: Crypto

Deck: Six sessions of redemptions put Bitcoin ETF outflows near $4.94 billion, testing institutional demand and market confidence.

## Article

Bitcoin’s institutional demand is facing a difficult test as US spot exchange-traded funds continue to record withdrawals. The latest available daily data show another $231.4 million leaving the funds on November 24, extending the outflow streak to six trading sessions. November’s cumulative net redemptions have reached approximately $4.94 billion, a level that puts the month among the weakest periods for the products since their launch.

Farside Investors’ daily flow table shows that US spot Bitcoin ETFs recorded net outflows of $569.7 million on November 23 and $231.4 million on November 24. The latest session included a $175.3 million outflow from BlackRock’s iShares Bitcoin Trust, known by its ticker IBIT, and a $44 million outflow from Fidelity’s FBTC. Smaller withdrawals came from Bitwise and ARK 21Shares products, while some funds recorded modest inflows. The aggregate remained negative.

The six-session sequence began on November 17. Funds lost $239.9 million that day, followed by $306.5 million on November 18, $582.3 million on November 19, $669.2 million on November 20, $569.7 million on November 23 and $231.4 million on November 24. Together, the withdrawals total about $2.60 billion. The month-to-date figure reached roughly $4.94 billion after the latest update, based on the daily totals in Farside’s table.

Bitcoin was trading around $59,300 on Wednesday morning, according to Reuters, after falling below $60,000. Ether also declined. The price move and ETF redemptions are related but should not be treated as identical measures. ETF flows record the net creation and redemption of fund shares; they do not directly measure every institutional purchase or sale of bitcoin in the wider market. Falling prices also reduce the value of assets held by the funds even when investors do not redeem shares.

BlackRock’s IBIT has accounted for a large share of recent withdrawals. Its $175.3 million outflow on November 24 followed a $509.3 million redemption on November 23 and larger withdrawals earlier in the week. That concentration matters because IBIT is the largest US spot Bitcoin ETF by assets and has been a major channel through which traditional investors gain exposure to bitcoin without holding the asset directly.

The figures do not prove that institutional investors have abandoned bitcoin. Net flows can reverse, and ETF activity is only one part of the market. Investors can hold bitcoin directly, use futures, trade offshore products or maintain exposure through other financial instruments. But repeated redemptions are a meaningful signal that demand through one of the most visible regulated investment channels has weakened.

A separate regulatory development in the United States points in a different direction. On November 23, staff at the Commodity Futures Trading Commission issued an advisory addressing whether bitcoin, ether and qualifying payment stablecoins can count toward certain financial-resource requirements for registered swap execution facilities, designated contract markets and derivatives clearing organizations. The staff said bitcoin and ether may be acceptable resources for specified operating-cost requirements, subject to valuation haircuts and liquidity conditions.

The guidance is narrower than a broad approval of crypto as regulatory capital. The advisory concerns resources used to cover operating costs, not default resources for a clearinghouse. It also requires firms to account for market and credit risk. CFTC staff said it would not object to a minimum 20% haircut for bitcoin and ether and a 2% haircut for qualifying payment stablecoins in the circumstances described. At least three months of the relevant resources must still consist of unencumbered liquid financial assets such as cash or highly liquid securities.

The distinction is important for market structure. The CFTC is acknowledging that certain digital assets may have a role in the financial resources of regulated derivatives businesses, but it is not treating them as equivalent to cash. Haircuts, liquidity requirements and the risk that crypto prices could fall at the same time as a firm faces operating stress remain central safeguards. The advisory is a staff position, not a rule that automatically applies to every crypto company or every token.

Together, the market and regulatory developments show two different sides of institutional adoption. Investors are withdrawing money from listed bitcoin products during a period of price weakness, while US regulators are continuing to define how digital assets can be used inside parts of the regulated financial system. One does not cancel out the other: product flows reflect investor positioning, while the CFTC advisory concerns the operational resources of specific market institutions.

For bitcoin investors, the near-term question is whether ETF redemptions slow as prices stabilize or continue to reinforce selling pressure. For the industry, the longer-term question is whether clearer rules can support more institutional infrastructure without weakening liquidity and risk controls. November’s outflows are a warning about current demand, not a final verdict on the future of regulated crypto markets.

## Related Reading

- [Bitcoin ETFs and Institutional Adoption](bitcoin-etf-institutional-adoption.html)
- [Stablecoin Pegs: Backing and Redemption Risks](stablecoins-explained-depeg-risk.html)
- [ECB Opens Collateral to Eligible DLT Securities](ecb-tokenized-securities-eurosystem-collateral-2027.html)

## Sources

- [Farside Investors – Bitcoin ETF Flows](https://farside.co.uk/btc/)
- [CFTC – Staff Advisory, Letter No. 26-31](https://www.cftc.gov/csl/26-31/download)
- [Reuters – Global Markets, November 25, 2026](https://www.reuters.com/world/china/global-markets-global-markets-2026-11-25/)