# Deutsche Bank Turns Bullish on US Technology Stocks After October Selloff

**Section:** Market Analysis  
**Date:** November 2, 2026  
**Status:** Approved image; article prepared for publication, not yet deployed  
**Dek:** The bank has reversed a recent downgrade after technology shares lagged the broader US market. Its argument rests on valuations, investor positioning and earnings, while the return on AI infrastructure spending remains uncertain.

Deutsche Bank has upgraded its view of US technology stocks after a sharp October selloff, reversing a downgrade made only three weeks earlier. Strategists argue that prices and investor positioning now offer a more favourable balance of potential return and risk. The change follows a month in which more than $2 trillion was erased from the Nasdaq 100's market value, according to Reuters.

The call is a shift in the bank's investment assessment, not evidence that the market has reached a bottom. Technology stocks can recover even as spending pressures persist, but the pace of any rebound will depend on earnings, interest rates and investors' willingness to pay for future growth.

## What changed in three weeks

The recent market decline went beyond routine daily volatility. Reuters reported that technology and mega-cap growth stocks fell roughly 11% over a three-week period, while the rest of the S&P 500 gained close to 6%. That left the growth group more than 16 percentage points behind the broader market excluding those stocks.

Such a large gap changes the comparison facing portfolio managers. Before the decline, a buyer might have been paying a considerable premium for expected earnings growth. After a sharp repricing, some of those same growth expectations may be available at lower share prices.

Deutsche Bank's argument, as reported by Reuters, is that much of the concern about AI investment costs is now reflected in valuations. The bank also points to lighter investor exposure, meaning fewer portfolios may be positioned for uninterrupted technology-sector gains than earlier in the year.

The judgement remains conditional. A lower stock price does not guarantee an attractive valuation if forecasts for revenue or profit deteriorate further. The bank's upgrade therefore depends on the earnings assumptions behind its analysis remaining sufficiently resilient.

## AI spending remains the central challenge

Large technology groups are building data centres, purchasing advanced processors and expanding energy and networking capacity to support AI services. These projects require upfront investment, often long before customers generate recurring revenue that can be clearly tied to that spending.

Capital expenditure can reduce near-term free cash flow even when a company's reported earnings remain healthy. Investors are therefore increasingly asking not just how much AI infrastructure a company can build, but what economic returns it expects from the additional capacity.

The challenge differs across business models. Cloud providers can seek revenue from customers renting computing resources. Chip designers and manufacturers depend on demand for equipment and components. Software businesses need to show that AI features improve sales, customer retention or productivity enough to justify their operating costs.

An upgrade to the technology sector does not mean all these businesses face the same opportunity. Debt levels, profit margins, competition and the useful life of computing equipment vary materially from company to company. Individual balance sheets remain important even when sector sentiment improves.

## Why investor positioning matters

Investment strategists examine how much exposure asset managers already hold because crowded positions can intensify a selloff. If many investors own similar stocks and decide to reduce risk simultaneously, market declines can become sharper than changes in company fundamentals alone might justify.

The reverse can also occur. After investors cut exposure, better-than-expected results or a less severe macroeconomic outlook may encourage them to rebuild positions. Those purchases can support prices even without an immediate acceleration in profit growth.

Deutsche Bank cited previous technology-sector rebounds from similarly weak relative-performance levels, according to Reuters. The reported historical average gain was around 32%, alongside approximately 30 percentage points of outperformance versus the rest of the S&P 500.

That figure describes past episodes selected by the bank, not a forecast or guaranteed return for today's market. Historical comparisons can be useful context, but the sample and economic conditions matter. Interest rates, company valuations and the scale of AI spending are not necessarily the same as during earlier recoveries.

## Earnings may determine whether the upgrade works

The strongest support for a technology rebound would come from profits that remain robust despite heavy investment. Companies need to demonstrate that their underlying products and services can finance expansion without placing sustained pressure on free cash flow.

Investors should also distinguish between the performance of a broad stock index and the financial results of individual companies. Major benchmarks are concentrated in a limited number of very large firms. Their share-price moves can dominate an index even when smaller businesses experience different conditions.

A rebound driven mostly by changes in valuation could be vulnerable if the next reporting season shows weaker growth. A rebound supported by rising profits and improving cash generation would have a firmer financial basis.

The economic backdrop presents additional variables. Bond yields influence the value assigned to future profits, while trade policy, regulation and energy costs can change the economics of AI infrastructure. Those factors could either reinforce or challenge Deutsche Bank's revised view.

## A reversal, not a resolution

The bank's change of stance highlights how quickly investment recommendations can respond to price movements. Three weeks ago, strategists considered technology stocks less attractive. After a large relative decline, they now see a more favourable entry point.

Both positions can be internally consistent if the price paid for expected earnings changes faster than the earnings outlook itself. What remains untested is the ultimate return on the industry's latest generation of AI investment.

For TTN Finance readers, the relevant development is the renewed disagreement over valuation. Some investors view the selloff as evidence that AI expectations were excessive. Deutsche Bank views the repricing as creating opportunity. Corporate results and cash flow will be more decisive than the upgrade headline in determining which interpretation holds up.

### Sources
- Reuters, November 2, 2026: https://www.reuters.com/legal/transactional/deutsche-bank-upgrades-us-tech-says-selloff-has-gone-too-far-2026-11-02/
- Investing.com, Reuters report with published research details: https://www.investing.com/news/stock-market-news/deutsche-bank-upgrades-us-techsays-selloff-has-gone-too-far-4990112
- Investing.com, October 31, strategy note coverage: https://www.investing.com/news/stock-market-news/tech-riskreward-turns-favorable-after-rout-deutsche-bank-says-4989239

### Internal link suggestions
- Existing TTN Finance article: `intel-amazon-ai-spending-tech-selloff-october-2026.html`
- Existing TTN Finance article: `meta-ai-credit-outlook-october-2026.html`
