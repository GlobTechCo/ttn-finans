DEWA × Shanghai Electric — approved one-article release
dewa-shanghai-electric-global-energy-mou-november-2026
Word count 840. Five publication inputs and this readme.
Upload to GitHub root unchanged as ZIP.
